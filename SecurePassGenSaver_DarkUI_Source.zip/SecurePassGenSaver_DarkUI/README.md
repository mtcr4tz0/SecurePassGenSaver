# SecurePassGenSaver

SecurePassGenSaver is an open-source C# Windows desktop password generator with a compact dark utility-style interface inspired by tools like Rufus and OpenRGB.

## Features

- Dark Windows Forms interface
- Generate passwords locally
- Uses `.NET RandomNumberGenerator`
- Choose password length from 8 to 32 characters
- Include/exclude lowercase, uppercase, numbers, and special characters
- Option to avoid ambiguous characters like `I`, `l`, `1`, `O`, and `0`
- Save passwords as Markdown files
- Choose a save folder, including a USB flash drive
- View saved password list
- Copy, edit, and delete saved entries
- Open saved files folder
- Accessibility text-to-speech option
- Dark/light/system theme setting
- Optional 4-digit app PIN with hint
- Help tab explaining privacy and offline generation

## Important Security Note

Saved password files are stored as readable Markdown plain text.  
The 4-digit app PIN only protects app access. It does not encrypt the saved files.

For real-world password storage, use a trusted password manager.

## How to Run

Install the .NET 8 SDK, then run:

```bash
dotnet run
```

## How to Build a Windows EXE

```bash
dotnet publish -c Release -r win-x64 --self-contained false /p:PublishSingleFile=true
```

The executable will be created in:

```text
bin/Release/net8.0-windows/win-x64/publish/
```

## Portfolio Purpose

This project was created as a beginner cybersecurity and programming portfolio project. It demonstrates C# programming, Windows Forms UI design, random password generation, entropy estimation, local file storage, basic privacy awareness, and project documentation.

## License

MIT License.
