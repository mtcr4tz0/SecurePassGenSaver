using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SecurePassGenSaver;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        AppPaths.EnsureFolders();

        AppSettings settings = SettingsService.Load();
        if (settings.PinEnabled)
        {
            using LockForm lockForm = new(settings);
            if (lockForm.ShowDialog() != DialogResult.OK) return;
        }

        Application.Run(new MainForm());
    }
}

public class AppSettings
{
    public string SaveFolder { get; set; } = AppPaths.DefaultSaveFolder;
    public string Theme { get; set; } = "Dark";
    public bool TextToSpeech { get; set; } = false;
    public bool PinEnabled { get; set; } = false;
    public string PinSalt { get; set; } = "";
    public string PinHash { get; set; } = "";
    public string PinHint { get; set; } = "";
}

public class PasswordEntry
{
    public string SaveName { get; set; } = "";
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public DateTime Created { get; set; } = DateTime.Now;
    public string FilePath { get; set; } = "";
}

public static class AppPaths
{
    public static string AppFolder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SecurePassGenSaver");
    public static string DefaultSaveFolder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SecurePassGenSaver");
    public static string SettingsFile => Path.Combine(AppFolder, "settings.json");

    public static void EnsureFolders()
    {
        Directory.CreateDirectory(AppFolder);
        Directory.CreateDirectory(DefaultSaveFolder);
    }
}

public static class SettingsService
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(AppPaths.SettingsFile))
            {
                AppSettings fresh = new();
                Save(fresh);
                return fresh;
            }

            AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(AppPaths.SettingsFile), JsonOptions);
            settings ??= new AppSettings();
            if (string.IsNullOrWhiteSpace(settings.SaveFolder)) settings.SaveFolder = AppPaths.DefaultSaveFolder;
            Directory.CreateDirectory(settings.SaveFolder);
            return settings;
        }
        catch
        {
            return new AppSettings();
        }
    }

    public static void Save(AppSettings settings)
    {
        Directory.CreateDirectory(AppPaths.AppFolder);
        Directory.CreateDirectory(settings.SaveFolder);
        File.WriteAllText(AppPaths.SettingsFile, JsonSerializer.Serialize(settings, JsonOptions));
    }

    public static void Reset()
    {
        if (File.Exists(AppPaths.SettingsFile)) File.Delete(AppPaths.SettingsFile);
        Save(new AppSettings());
    }
}

public static class PasswordGenerator
{
    private const string Lower = "abcdefghijklmnopqrstuvwxyz";
    private const string Upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private const string Digits = "0123456789";
    private const string Symbols = "!@#$%^&*()-_=+[]{};:,.<>?";
    private const string Ambiguous = "Il1O0";

    public static string Generate(int length, bool lower, bool upper, bool digits, bool symbols, bool avoidAmbiguous)
    {
        List<string> sets = new();
        if (lower) sets.Add(Clean(Lower, avoidAmbiguous));
        if (upper) sets.Add(Clean(Upper, avoidAmbiguous));
        if (digits) sets.Add(Clean(Digits, avoidAmbiguous));
        if (symbols) sets.Add(Symbols);
        sets = sets.Where(s => s.Length > 0).ToList();
        if (sets.Count == 0) sets.Add(Clean(Lower, avoidAmbiguous));

        string all = string.Concat(sets);
        List<char> chars = new();

        foreach (string set in sets)
        {
            if (chars.Count < length) chars.Add(RandomChar(set));
        }

        while (chars.Count < length) chars.Add(RandomChar(all));
        Shuffle(chars);
        return new string(chars.ToArray());
    }

    public static double Entropy(int length, bool lower, bool upper, bool digits, bool symbols, bool avoidAmbiguous)
    {
        int pool = 0;
        if (lower) pool += Clean(Lower, avoidAmbiguous).Length;
        if (upper) pool += Clean(Upper, avoidAmbiguous).Length;
        if (digits) pool += Clean(Digits, avoidAmbiguous).Length;
        if (symbols) pool += Symbols.Length;
        if (pool <= 0) pool = Clean(Lower, avoidAmbiguous).Length;
        return length * Math.Log2(pool);
    }

    public static string Strength(double entropy)
    {
        if (entropy >= 100) return "VERY STRONG";
        if (entropy >= 80) return "STRONG";
        if (entropy >= 60) return "GOOD";
        if (entropy >= 40) return "WEAK";
        return "VERY WEAK";
    }

    private static string Clean(string chars, bool avoid) => avoid ? new string(chars.Where(c => !Ambiguous.Contains(c)).ToArray()) : chars;
    private static char RandomChar(string chars) => chars[RandomNumberGenerator.GetInt32(chars.Length)];

    private static void Shuffle(List<char> chars)
    {
        for (int i = chars.Count - 1; i > 0; i--)
        {
            int j = RandomNumberGenerator.GetInt32(i + 1);
            (chars[i], chars[j]) = (chars[j], chars[i]);
        }
    }
}

public static class PasswordStore
{
    public static PasswordEntry Save(string folder, PasswordEntry entry)
    {
        Directory.CreateDirectory(folder);
        string name = SafeFileName(string.IsNullOrWhiteSpace(entry.SaveName) ? "password" : entry.SaveName);
        string path = string.IsNullOrWhiteSpace(entry.FilePath)
            ? Path.Combine(folder, $"{name}_{DateTime.Now:yyyyMMdd_HHmmss}.md")
            : entry.FilePath;

        string content = $"""
# SecurePassGenSaver Password Entry

**Save Name:** {entry.SaveName}
**Username:** {entry.Username}
**Created:** {entry.Created}

**Password:** `{entry.Password}`

## Security Note

This file stores the password in readable plain text. Keep it only in a trusted folder or external drive.

Generated locally by SecurePassGenSaver.
""";

        File.WriteAllText(path, content);
        entry.FilePath = path;
        return entry;
    }

    public static List<PasswordEntry> Load(string folder)
    {
        Directory.CreateDirectory(folder);
        List<PasswordEntry> entries = new();

        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            try
            {
                string text = File.ReadAllText(file);
                PasswordEntry entry = new()
                {
                    SaveName = Match(text, @"\*\*Save Name:\*\*\s*(.+)"),
                    Username = Match(text, @"\*\*Username:\*\*\s*(.+)"),
                    Password = Match(text, @"\*\*Password:\*\*\s*`([^`]*)`"),
                    FilePath = file,
                    Created = File.GetCreationTime(file)
                };

                string created = Match(text, @"\*\*Created:\*\*\s*(.+)");
                if (DateTime.TryParse(created, out DateTime parsed)) entry.Created = parsed;
                if (!string.IsNullOrWhiteSpace(entry.Password)) entries.Add(entry);
            }
            catch { }
        }

        return entries.OrderByDescending(e => e.Created).ToList();
    }

    public static void Delete(PasswordEntry entry)
    {
        if (File.Exists(entry.FilePath)) File.Delete(entry.FilePath);
    }

    public static void DeleteAll(string folder)
    {
        Directory.CreateDirectory(folder);
        foreach (string file in Directory.GetFiles(folder, "*.md")) File.Delete(file);
    }

    public static void OpenFolder(string folder)
    {
        Directory.CreateDirectory(folder);
        Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
    }

    private static string Match(string text, string pattern)
    {
        Match m = Regex.Match(text, pattern);
        return m.Success ? m.Groups[1].Value.Trim() : "";
    }

    private static string SafeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
        return name.Trim();
    }
}

public static class PinManager
{
    private const int SaltSize = 16;
    private const int HashSize = 32;
    private const int Iterations = 100_000;

    public static bool ValidFormat(string pin) => pin.Length == 4 && pin.All(char.IsDigit);

    public static void Set(AppSettings settings, string pin, string hint)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = Hash(pin, salt);
        settings.PinEnabled = true;
        settings.PinSalt = Convert.ToBase64String(salt);
        settings.PinHash = Convert.ToBase64String(hash);
        settings.PinHint = hint.Trim();
    }

    public static void Disable(AppSettings settings)
    {
        settings.PinEnabled = false;
        settings.PinSalt = "";
        settings.PinHash = "";
        settings.PinHint = "";
    }

    public static bool Verify(AppSettings settings, string pin)
    {
        if (!settings.PinEnabled) return true;
        if (string.IsNullOrWhiteSpace(settings.PinSalt) || string.IsNullOrWhiteSpace(settings.PinHash)) return false;
        byte[] salt = Convert.FromBase64String(settings.PinSalt);
        byte[] expected = Convert.FromBase64String(settings.PinHash);
        byte[] actual = Hash(pin, salt);
        return CryptographicOperations.FixedTimeEquals(expected, actual);
    }

    private static byte[] Hash(string pin, byte[] salt)
    {
        using Rfc2898DeriveBytes pbkdf2 = new(pin, salt, Iterations, HashAlgorithmName.SHA256);
        return pbkdf2.GetBytes(HashSize);
    }
}

public static class UiTheme
{
    public static readonly Color Back = Color.FromArgb(32, 32, 32);
    public static readonly Color Panel = Color.FromArgb(46, 46, 46);
    public static readonly Color Control = Color.FromArgb(55, 55, 55);
    public static readonly Color Border = Color.FromArgb(95, 95, 95);
    public static readonly Color Text = Color.WhiteSmoke;

    public static void Dark(Control root)
    {
        root.BackColor = Back;
        root.ForeColor = Text;
        foreach (Control c in All(root))
        {
            c.ForeColor = Text;
            if (c is TabPage) c.BackColor = Back;
            else if (c is GroupBox) c.BackColor = Back;
            else if (c is Panel) c.BackColor = Panel;
            else if (c is TextBox tb) { tb.BackColor = Control; tb.ForeColor = Text; tb.BorderStyle = BorderStyle.FixedSingle; }
            else if (c is ListBox lb) { lb.BackColor = Control; lb.ForeColor = Text; }
            else if (c is ComboBox cb) { cb.BackColor = Control; cb.ForeColor = Text; }
            else if (c is Button b) { b.BackColor = Control; b.ForeColor = Text; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderColor = Border; }
            else if (c is DataGridView g)
            {
                g.BackgroundColor = Control;
                g.GridColor = Border;
                g.EnableHeadersVisualStyles = false;
                g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(42, 42, 42);
                g.ColumnHeadersDefaultCellStyle.ForeColor = Text;
                g.DefaultCellStyle.BackColor = Control;
                g.DefaultCellStyle.ForeColor = Text;
                g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(80, 80, 80);
                g.DefaultCellStyle.SelectionForeColor = Text;
            }
        }
    }

    public static void Light(Control root)
    {
        root.BackColor = SystemColors.Control;
        root.ForeColor = SystemColors.ControlText;
    }

    private static IEnumerable<Control> All(Control root)
    {
        foreach (Control c in root.Controls)
        {
            yield return c;
            foreach (Control child in All(c)) yield return child;
        }
    }
}

public class LockForm : Form
{
    private readonly AppSettings settings;
    private readonly TextBox pinBox = new();
    private readonly Label message = new();

    public LockForm(AppSettings settings)
    {
        this.settings = settings;
        Text = "SecurePassGenSaver Locked";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 380;
        Height = 230;

        Label title = new() { Text = "Enter your 4-digit PIN", Left = 25, Top = 25, Width = 280, Font = new Font(Font.FontFamily, 12, FontStyle.Bold) };
        pinBox.SetBounds(25, 65, 300, 25);
        pinBox.MaxLength = 4;
        pinBox.PasswordChar = '●';

        Button unlock = new() { Text = "UNLOCK", Left = 25, Top = 105, Width = 100 };
        unlock.Click += (_, _) => TryUnlock();
        Button cancel = new() { Text = "CANCEL", Left = 135, Top = 105, Width = 100 };
        cancel.Click += (_, _) => DialogResult = DialogResult.Cancel;

        Label hint = new() { Text = string.IsNullOrWhiteSpace(settings.PinHint) ? "Hint: no hint set" : $"Hint: {settings.PinHint}", Left = 25, Top = 145, Width = 320 };
        message.SetBounds(25, 170, 320, 25);

        Controls.AddRange(new Control[] { title, pinBox, unlock, cancel, hint, message });
        AcceptButton = unlock;
        UiTheme.Dark(this);
    }

    private void TryUnlock()
    {
        if (PinManager.Verify(settings, pinBox.Text)) DialogResult = DialogResult.OK;
        else { message.Text = "Wrong PIN."; pinBox.Clear(); }
    }
}

public class MainForm : Form
{
    private AppSettings settings = SettingsService.Load();
    private readonly TabControl tabs = new();

    private TextBox saveNameBox = new();
    private TextBox usernameBox = new();
    private TextBox passwordBox = new();
    private TrackBar lengthSlider = new();
    private Label lengthLabel = new();
    private Label entropyLabel = new();
    private Label statusLabel = new();
    private CheckBox lowerCheck = new();
    private CheckBox upperCheck = new();
    private CheckBox numberCheck = new();
    private CheckBox symbolCheck = new();
    private CheckBox ambiguousCheck = new();

    private DataGridView passwordGrid = new();
    private ListBox fileList = new();
    private TextBox folderBox = new();
    private CheckBox ttsCheck = new();
    private ComboBox themeCombo = new();
    private CheckBox pinEnabledCheck = new();
    private TextBox pinBox = new();
    private TextBox pinConfirmBox = new();
    private TextBox pinHintBox = new();

    public MainForm()
    {
        Text = "SecurePassGenSaver";
        Width = 920;
        Height = 570;
        MinimumSize = new Size(880, 540);
        StartPosition = FormStartPosition.CenterScreen;

        tabs.Dock = DockStyle.Fill;
        tabs.TabPages.Add(GenerateTab());
        tabs.TabPages.Add(PasswordListTab());
        tabs.TabPages.Add(SavedFilesTab());
        tabs.TabPages.Add(OptionsTab());
        tabs.TabPages.Add(SettingsTab());
        tabs.TabPages.Add(AboutTab());
        Controls.Add(tabs);

        LoadSettingsIntoControls();
        RefreshPasswordList();
        RefreshFiles();
        UpdateEntropy();
        ApplyTheme();
    }

    private GroupBox Section(string title, int x, int y, int w, int h) => new()
    {
        Text = title,
        Left = x,
        Top = y,
        Width = w,
        Height = h,
        Font = new Font(Font.FontFamily, 10, FontStyle.Bold)
    };

    private TabPage GenerateTab()
    {
        TabPage tab = new("Generate Password");

        GroupBox entry = Section("Entry Properties", 16, 16, 855, 165);
        entry.Controls.Add(new Label { Text = "Save file name", Left = 18, Top = 32, Width = 130 });
        saveNameBox = new TextBox { Left = 150, Top = 29, Width = 660 };
        entry.Controls.Add(saveNameBox);
        entry.Controls.Add(new Label { Text = "Username", Left = 18, Top = 72, Width = 130 });
        usernameBox = new TextBox { Left = 150, Top = 69, Width = 660 };
        entry.Controls.Add(usernameBox);
        entry.Controls.Add(new Label { Text = "Password", Left = 18, Top = 112, Width = 130 });
        passwordBox = new TextBox { Left = 150, Top = 109, Width = 520, ReadOnly = true };
        entry.Controls.Add(passwordBox);
        Button copy = new() { Text = "COPY", Left = 680, Top = 108, Width = 60, Height = 25 };
        copy.Click += (_, _) => CopyGenerated();
        Button save = new() { Text = "SAVE", Left = 750, Top = 108, Width = 60, Height = 25 };
        save.Click += (_, _) => SaveGenerated();
        entry.Controls.Add(copy); entry.Controls.Add(save);

        GroupBox gen = Section("Generator Options", 16, 195, 855, 210);
        lengthLabel = new Label { Left = 18, Top = 32, Width = 150 };
        lengthSlider = new TrackBar { Left = 150, Top = 25, Width = 660, Minimum = 8, Maximum = 32, TickFrequency = 4, Value = 16 };
        lengthSlider.Scroll += (_, _) => UpdateEntropy();
        lowerCheck = new CheckBox { Text = "Include lowercase", Left = 150, Top = 80, Width = 180, Checked = true };
        upperCheck = new CheckBox { Text = "Include uppercase", Left = 340, Top = 80, Width = 180, Checked = true };
        numberCheck = new CheckBox { Text = "Include numbers", Left = 530, Top = 80, Width = 180, Checked = true };
        symbolCheck = new CheckBox { Text = "Include special characters (@#$%&!)", Left = 150, Top = 115, Width = 300, Checked = true };
        ambiguousCheck = new CheckBox { Text = "Avoid ambiguous characters (I, l, 1, O, 0)", Left = 460, Top = 115, Width = 350, Checked = true };
        lowerCheck.CheckedChanged += (_, _) => UpdateEntropy();
        upperCheck.CheckedChanged += (_, _) => UpdateEntropy();
        numberCheck.CheckedChanged += (_, _) => UpdateEntropy();
        symbolCheck.CheckedChanged += (_, _) => UpdateEntropy();
        ambiguousCheck.CheckedChanged += (_, _) => UpdateEntropy();
        Button generate = new() { Text = "GENERATE", Left = 680, Top = 155, Width = 130, Height = 30 };
        generate.Click += (_, _) => Generate();
        gen.Controls.AddRange(new Control[] { lengthLabel, lengthSlider, lowerCheck, upperCheck, numberCheck, symbolCheck, ambiguousCheck, generate });

        GroupBox status = Section("Status", 16, 420, 855, 70);
        entropyLabel = new Label { Left = 18, Top = 30, Width = 340 };
        statusLabel = new Label { Text = "READY", Left = 370, Top = 24, Width = 440, Height = 28, TextAlign = ContentAlignment.MiddleCenter, BorderStyle = BorderStyle.FixedSingle };
        status.Controls.AddRange(new Control[] { entropyLabel, statusLabel });

        tab.Controls.AddRange(new Control[] { entry, gen, status });
        return tab;
    }

    private TabPage PasswordListTab()
    {
        TabPage tab = new("Password List");
        GroupBox box = Section("Saved Password List", 16, 16, 855, 390);
        passwordGrid = new DataGridView { Left = 18, Top = 30, Width = 815, Height = 335, ReadOnly = true, AllowUserToAddRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
        box.Controls.Add(passwordGrid);
        Button copy = new() { Text = "COPY", Left = 16, Top = 420, Width = 100 };
        Button edit = new() { Text = "EDIT", Left = 126, Top = 420, Width = 100 };
        Button delete = new() { Text = "DELETE", Left = 236, Top = 420, Width = 100 };
        Button refresh = new() { Text = "REFRESH", Left = 346, Top = 420, Width = 100 };
        copy.Click += (_, _) => CopySelected();
        edit.Click += (_, _) => EditSelected();
        delete.Click += (_, _) => DeleteSelected();
        refresh.Click += (_, _) => RefreshPasswordList();
        Label warning = new() { Text = "Saved files are Markdown plain text. Use a trusted folder or removable drive.", Left = 16, Top = 465, Width = 760, Height = 30 };
        tab.Controls.AddRange(new Control[] { box, copy, edit, delete, refresh, warning });
        return tab;
    }

    private TabPage SavedFilesTab()
    {
        TabPage tab = new("Saved Files");
        GroupBox folder = Section("Save Location", 16, 16, 855, 100);
        folder.Controls.Add(new Label { Text = "Folder", Left = 18, Top = 38, Width = 100 });
        folderBox = new TextBox { Left = 120, Top = 35, Width = 560, ReadOnly = true };
        Button choose = new() { Text = "SELECT", Left = 695, Top = 34, Width = 90 };
        Button open = new() { Text = "OPEN", Left = 790, Top = 34, Width = 55 };
        choose.Click += (_, _) => ChooseFolder();
        open.Click += (_, _) => PasswordStore.OpenFolder(settings.SaveFolder);
        folder.Controls.AddRange(new Control[] { folderBox, choose, open });
        GroupBox files = Section("Files", 16, 135, 855, 315);
        fileList = new ListBox { Left = 18, Top = 30, Width = 815, Height = 260 };
        files.Controls.Add(fileList);
        Button refresh = new() { Text = "REFRESH", Left = 16, Top = 465, Width = 100 };
        refresh.Click += (_, _) => RefreshFiles();
        tab.Controls.AddRange(new Control[] { folder, files, refresh });
        return tab;
    }

    private TabPage OptionsTab()
    {
        TabPage tab = new("Options");
        GroupBox accessibility = Section("Accessibility", 16, 16, 855, 120);
        ttsCheck = new CheckBox { Text = "Enable text-to-speech status messages", Left = 18, Top = 35, Width = 320 };
        ttsCheck.CheckedChanged += (_, _) => { settings.TextToSpeech = ttsCheck.Checked; SettingsService.Save(settings); };
        Button test = new() { Text = "TEST", Left = 350, Top = 32, Width = 80 };
        test.Click += (_, _) => Speak("Text to speech is enabled.");
        accessibility.Controls.AddRange(new Control[] { ttsCheck, test });
        GroupBox data = Section("Data Management", 16, 155, 855, 165);
        Button deleteData = new() { Text = "DELETE ALL SAVED PASSWORD FILES", Left = 18, Top = 35, Width = 280 };
        Button reset = new() { Text = "RESET APP SETTINGS", Left = 18, Top = 80, Width = 280 };
        deleteData.Click += (_, _) => DeleteAllData();
        reset.Click += (_, _) => ResetSettings();
        Label note = new() { Text = "The app cannot safely uninstall itself. To remove it, delete the published folder or uninstall it through Windows if you create an installer.", Left = 320, Top = 38, Width = 500, Height = 75 };
        data.Controls.AddRange(new Control[] { deleteData, reset, note });
        tab.Controls.AddRange(new Control[] { accessibility, data });
        return tab;
    }

    private TabPage SettingsTab()
    {
        TabPage tab = new("Settings");
        GroupBox appearance = Section("Appearance", 16, 16, 855, 100);
        appearance.Controls.Add(new Label { Text = "Theme", Left = 18, Top = 38, Width = 100 });
        themeCombo = new ComboBox { Left = 120, Top = 35, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        themeCombo.Items.AddRange(new object[] { "Dark", "Light", "System" });
        themeCombo.SelectedIndexChanged += (_, _) => { settings.Theme = themeCombo.SelectedItem?.ToString() ?? "Dark"; SettingsService.Save(settings); ApplyTheme(); };
        appearance.Controls.Add(themeCombo);

        GroupBox pin = Section("App PIN Lock", 16, 135, 855, 245);
        Label warning = new() { Text = "PIN lock protects app access only. It does NOT encrypt saved password files.", Left = 18, Top = 30, Width = 700 };
        pinEnabledCheck = new CheckBox { Text = "Enable 4-digit PIN", Left = 18, Top = 65, Width = 180 };
        pin.Controls.AddRange(new Control[] { warning, pinEnabledCheck });
        pin.Controls.Add(new Label { Text = "PIN", Left = 18, Top = 105, Width = 100 });
        pinBox = new TextBox { Left = 120, Top = 102, Width = 140, MaxLength = 4, PasswordChar = '●' };
        pin.Controls.Add(pinBox);
        pin.Controls.Add(new Label { Text = "Confirm PIN", Left = 18, Top = 145, Width = 100 });
        pinConfirmBox = new TextBox { Left = 120, Top = 142, Width = 140, MaxLength = 4, PasswordChar = '●' };
        pin.Controls.Add(pinConfirmBox);
        pin.Controls.Add(new Label { Text = "Hint", Left = 300, Top = 105, Width = 80 });
        pinHintBox = new TextBox { Left = 385, Top = 102, Width = 330 };
        pin.Controls.Add(pinHintBox);
        Button savePin = new() { Text = "SAVE PIN", Left = 120, Top = 185, Width = 110 };
        Button disablePin = new() { Text = "DISABLE PIN", Left = 240, Top = 185, Width = 120 };
        savePin.Click += (_, _) => SavePinSettings();
        disablePin.Click += (_, _) => DisablePin();
        pin.Controls.AddRange(new Control[] { savePin, disablePin });
        tab.Controls.AddRange(new Control[] { appearance, pin });
        return tab;
    }

    private TabPage AboutTab()
    {
        TabPage tab = new("?");
        GroupBox info = Section("Information", 16, 16, 855, 455);
        TextBox about = new()
        {
            Left = 18,
            Top = 30,
            Width = 815,
            Height = 395,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Text = "SecurePassGenSaver\r\n\r\nThis is an open-source C# Windows Forms password generator.\r\n\r\nRandom generation:\r\n- Passwords are generated locally on your computer.\r\n- The app uses RandomNumberGenerator from .NET.\r\n- No internet connection is required.\r\n- No passwords are sent anywhere.\r\n- No tracking or analytics are included.\r\n\r\nPrivacy:\r\n- Generated passwords stay on your device.\r\n- Saved Markdown files are readable plain text.\r\n- A 4-digit app PIN only locks app access. It does not encrypt saved password files.\r\n\r\nPortfolio purpose:\r\nThis project demonstrates C# programming, Windows Forms UI design, random password generation, entropy estimation, local file storage, and basic cybersecurity awareness."
        };
        info.Controls.Add(about);
        tab.Controls.Add(info);
        return tab;
    }

    private void Generate()
    {
        passwordBox.Text = PasswordGenerator.Generate(lengthSlider.Value, lowerCheck.Checked, upperCheck.Checked, numberCheck.Checked, symbolCheck.Checked, ambiguousCheck.Checked);
        statusLabel.Text = "GENERATED - " + PasswordGenerator.Strength(CurrentEntropy());
        Speak("Password generated.");
    }

    private void SaveGenerated()
    {
        if (string.IsNullOrWhiteSpace(passwordBox.Text)) { MessageBox.Show("Generate a password first."); return; }
        PasswordEntry entry = new()
        {
            SaveName = string.IsNullOrWhiteSpace(saveNameBox.Text) ? "password" : saveNameBox.Text.Trim(),
            Username = usernameBox.Text.Trim(),
            Password = passwordBox.Text.Trim(),
            Created = DateTime.Now
        };
        PasswordStore.Save(settings.SaveFolder, entry);
        statusLabel.Text = "SAVED";
        RefreshPasswordList();
        RefreshFiles();
        Speak("Password saved.");
    }

    private void CopyGenerated()
    {
        if (!string.IsNullOrWhiteSpace(passwordBox.Text)) { Clipboard.SetText(passwordBox.Text); statusLabel.Text = "COPIED"; }
    }

    private PasswordEntry? SelectedEntry()
    {
        if (passwordGrid.CurrentRow?.DataBoundItem is PasswordEntry entry) return entry;
        MessageBox.Show("Select a saved password first.");
        return null;
    }

    private void CopySelected()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;
        Clipboard.SetText(entry.Password);
        MessageBox.Show("Password copied.");
    }

    private void EditSelected()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        string? edited = PromptForPasswordEdit(entry.Password);
        if (string.IsNullOrWhiteSpace(edited)) return;

        entry.Password = edited.Trim();
        PasswordStore.Save(settings.SaveFolder, entry);
        RefreshPasswordList();
        RefreshFiles();
    }

    private string? PromptForPasswordEdit(string currentPassword)
    {
        using Form form = new()
        {
            Text = "Edit Saved Password",
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            Width = 470,
            Height = 180
        };

        Label label = new() { Text = "Password", Left = 20, Top = 25, Width = 100 };
        TextBox box = new() { Left = 120, Top = 22, Width = 300, Text = currentPassword };
        Button saveButton = new() { Text = "SAVE", Left = 220, Top = 75, Width = 90 };
        Button cancelButton = new() { Text = "CANCEL", Left = 330, Top = 75, Width = 90 };

        saveButton.Click += (_, _) => form.DialogResult = DialogResult.OK;
        cancelButton.Click += (_, _) => form.DialogResult = DialogResult.Cancel;

        form.Controls.AddRange(new Control[] { label, box, saveButton, cancelButton });
        form.AcceptButton = saveButton;
        form.CancelButton = cancelButton;
        UiTheme.Dark(form);

        return form.ShowDialog(this) == DialogResult.OK ? box.Text : null;
    }

    private void DeleteSelected()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;
        if (MessageBox.Show("Delete this saved password file?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        PasswordStore.Delete(entry);
        RefreshPasswordList();
        RefreshFiles();
    }

    private void RefreshPasswordList()
    {
        List<PasswordEntry> entries = PasswordStore.Load(settings.SaveFolder);
        passwordGrid.DataSource = null;
        passwordGrid.DataSource = entries;
        if (passwordGrid.Columns["Password"] != null) passwordGrid.Columns["Password"].Visible = false;
        if (passwordGrid.Columns["FilePath"] != null) passwordGrid.Columns["FilePath"].Visible = false;
    }

    private void RefreshFiles()
    {
        Directory.CreateDirectory(settings.SaveFolder);
        folderBox.Text = settings.SaveFolder;
        fileList.Items.Clear();
        foreach (string file in Directory.GetFiles(settings.SaveFolder, "*.md").OrderByDescending(File.GetCreationTime))
            fileList.Items.Add(Path.GetFileName(file));
    }

    private void ChooseFolder()
    {
        using FolderBrowserDialog dialog = new() { Description = "Choose a folder or flash drive for saved password files" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        settings.SaveFolder = dialog.SelectedPath;
        SettingsService.Save(settings);
        RefreshPasswordList();
        RefreshFiles();
    }

    private void DeleteAllData()
    {
        if (MessageBox.Show("Delete ALL saved password files in the selected folder?", "Danger", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        PasswordStore.DeleteAll(settings.SaveFolder);
        RefreshPasswordList();
        RefreshFiles();
    }

    private void ResetSettings()
    {
        if (MessageBox.Show("Reset app settings and disable PIN?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        SettingsService.Reset();
        settings = SettingsService.Load();
        LoadSettingsIntoControls();
        RefreshPasswordList();
        RefreshFiles();
        ApplyTheme();
    }

    private void SavePinSettings()
    {
        if (!pinEnabledCheck.Checked) { DisablePin(); return; }
        string pin = pinBox.Text.Trim();
        string confirm = pinConfirmBox.Text.Trim();
        if (!PinManager.ValidFormat(pin)) { MessageBox.Show("PIN must be exactly 4 digits."); return; }
        if (pin != confirm) { MessageBox.Show("PIN confirmation does not match."); return; }
        PinManager.Set(settings, pin, pinHintBox.Text);
        SettingsService.Save(settings);
        pinBox.Clear(); pinConfirmBox.Clear();
        MessageBox.Show("PIN enabled. It will be required next time the app opens.");
    }

    private void DisablePin()
    {
        PinManager.Disable(settings);
        SettingsService.Save(settings);
        pinEnabledCheck.Checked = false;
        pinBox.Clear(); pinConfirmBox.Clear(); pinHintBox.Clear();
        MessageBox.Show("PIN disabled.");
    }

    private void LoadSettingsIntoControls()
    {
        ttsCheck.Checked = settings.TextToSpeech;
        themeCombo.SelectedItem = settings.Theme;
        if (themeCombo.SelectedItem == null) themeCombo.SelectedItem = "Dark";
        pinEnabledCheck.Checked = settings.PinEnabled;
        pinHintBox.Text = settings.PinHint;
    }

    private double CurrentEntropy() => PasswordGenerator.Entropy(lengthSlider.Value, lowerCheck.Checked, upperCheck.Checked, numberCheck.Checked, symbolCheck.Checked, ambiguousCheck.Checked);

    private void UpdateEntropy()
    {
        lengthLabel.Text = $"Length: {lengthSlider.Value} characters";
        double entropy = CurrentEntropy();
        entropyLabel.Text = $"Entropy: {entropy:0.00} bits / {PasswordGenerator.Strength(entropy)}";
    }

    private void Speak(string text)
    {
        if (!settings.TextToSpeech) return;
        try
        {
            Type? voiceType = Type.GetTypeFromProgID("SAPI.SpVoice");
            if (voiceType == null) return;
            dynamic? voice = Activator.CreateInstance(voiceType);
            voice?.Speak(text);
        }
        catch { }
    }

    private void ApplyTheme()
    {
        if (settings.Theme == "Light") UiTheme.Light(this);
        else UiTheme.Dark(this);
    }
}
