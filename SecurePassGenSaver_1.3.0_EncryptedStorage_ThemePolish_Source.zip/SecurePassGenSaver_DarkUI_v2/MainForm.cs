namespace SecurePassGenSaver;

public class MainForm : Form
{
    private AppSettings _settings;

    private readonly ThemedTabControl _tabs = new();

    private TextBox _saveNameBox = new();
    private TextBox _usernameBox = new();
    private TextBox _passwordBox = new();
    private TrackBar _lengthSlider = new();
    private Label _lengthBubble = new();
    private Label _entropyLabel = new();
    private Label _statusLabel = new();

    private CheckBox _lowercaseCheck = new();
    private CheckBox _uppercaseCheck = new();
    private CheckBox _numbersCheck = new();
    private CheckBox _symbolsCheck = new();
    private CheckBox _ambiguousCheck = new();

    private DataGridView _passwordGrid = new();
    private ListBox _fileList = new();
    private TextBox _saveFolderBox = new();

    private CheckBox _ttsCheck = new();
    private ComboBox _themeCombo = new();
    private CheckBox _pinEnabledCheck = new();
    private TextBox _pinBox = new();
    private TextBox _pinConfirmBox = new();
    private TextBox _pinHintBox = new();

    public MainForm()
    {
        _settings = SettingsService.Load();

        Text = "SecurePassGenSaver";
        StartPosition = FormStartPosition.CenterScreen;
        Width = 920;
        Height = 570;
        MinimumSize = new Size(880, 540);

        BuildTabs();
        Controls.Add(_tabs);

        RefreshPasswordList();
        RefreshFileList();
        LoadSettingsToControls();
        ApplyCurrentTheme();
        UpdateLengthAndEntropy();
    }

    private void BuildTabs()
    {
        _tabs.Dock = DockStyle.Fill;

        _tabs.TabPages.Add(BuildGenerateTab());
        _tabs.TabPages.Add(BuildPasswordListTab());
        _tabs.TabPages.Add(BuildSavedFilesTab());
        _tabs.TabPages.Add(BuildOptionsTab());
        _tabs.TabPages.Add(BuildSettingsTab());
        _tabs.TabPages.Add(BuildAboutTab());
    }

    private GroupBox Section(string title, int left, int top, int width, int height)
    {
        return new GroupBox
        {
            Text = title,
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            Font = new Font(Font.FontFamily, 10, FontStyle.Bold)
        };
    }

    private TabPage BuildGenerateTab()
    {
        TabPage tab = new("Generate");

        GroupBox inputSection = Section("Entry Properties", 16, 16, 855, 165);

        Label saveNameLabel = new() { Text = "Save file name", Left = 18, Top = 32, Width = 130 };
        _saveNameBox = new TextBox { Left = 150, Top = 29, Width = 660 };

        Label usernameLabel = new() { Text = "Username", Left = 18, Top = 72, Width = 130 };
        _usernameBox = new TextBox { Left = 150, Top = 69, Width = 660 };

        Label passwordLabel = new() { Text = "Password", Left = 18, Top = 112, Width = 130 };
        _passwordBox = new TextBox { Left = 150, Top = 109, Width = 520, ReadOnly = true };

        Button copyButton = new() { Text = "COPY", Left = 680, Top = 108, Width = 60, Height = 25 };
        copyButton.Click += (_, _) => CopyGeneratedPassword();

        Button saveButton = new() { Text = "SAVE", Left = 750, Top = 108, Width = 60, Height = 25 };
        saveButton.Click += (_, _) => SaveCurrentPassword();

        inputSection.Controls.Add(saveNameLabel);
        inputSection.Controls.Add(_saveNameBox);
        inputSection.Controls.Add(usernameLabel);
        inputSection.Controls.Add(_usernameBox);
        inputSection.Controls.Add(passwordLabel);
        inputSection.Controls.Add(_passwordBox);
        inputSection.Controls.Add(copyButton);
        inputSection.Controls.Add(saveButton);

        GroupBox generatorSection = Section("Generator Options", 16, 195, 855, 225);

        Label minLabel = new() { Text = "8", Left = 150, Top = 92, Width = 30 };
        Label maxLabel = new() { Text = "32", Left = 780, Top = 92, Width = 40, TextAlign = ContentAlignment.MiddleRight };

        _lengthBubble = new Label
        {
            Text = "16",
            Left = 0,
            Top = 34,
            Width = 48,
            Height = 24,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font(Font.FontFamily, 9, FontStyle.Bold)
        };

        _lengthSlider = new TrackBar
        {
            Left = 150,
            Top = 60,
            Width = 660,
            Minimum = 8,
            Maximum = 32,
            TickFrequency = 4,
            Value = 16,
            AutoSize = false,
            Height = 36
        };
        _lengthSlider.ValueChanged += (_, _) => UpdateLengthAndEntropy();

        _lowercaseCheck = new CheckBox { Text = "Include lowercase", Left = 150, Top = 120, Width = 180, Checked = true };
        _uppercaseCheck = new CheckBox { Text = "Include uppercase", Left = 340, Top = 120, Width = 180, Checked = true };
        _numbersCheck = new CheckBox { Text = "Include numbers", Left = 530, Top = 120, Width = 180, Checked = true };
        _symbolsCheck = new CheckBox { Text = "Include special characters (@#$%&!)", Left = 150, Top = 155, Width = 300, Checked = true };
        _ambiguousCheck = new CheckBox { Text = "Avoid ambiguous characters (I, l, 1, O, 0)", Left = 460, Top = 155, Width = 350, Checked = true };

        _lowercaseCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _uppercaseCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _numbersCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _symbolsCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _ambiguousCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();

        Button generateButton = new() { Text = "GENERATE", Left = 680, Top = 185, Width = 130, Height = 30 };
        generateButton.Click += (_, _) => GeneratePassword();

        generatorSection.Controls.Add(_lengthBubble);
        generatorSection.Controls.Add(_lengthSlider);
        generatorSection.Controls.Add(minLabel);
        generatorSection.Controls.Add(maxLabel);
        generatorSection.Controls.Add(_lowercaseCheck);
        generatorSection.Controls.Add(_uppercaseCheck);
        generatorSection.Controls.Add(_numbersCheck);
        generatorSection.Controls.Add(_symbolsCheck);
        generatorSection.Controls.Add(_ambiguousCheck);
        generatorSection.Controls.Add(generateButton);

        GroupBox statusSection = Section("Status", 16, 435, 855, 60);
        _entropyLabel = new Label { Left = 18, Top = 25, Width = 340, Text = "Entropy: -" };
        _statusLabel = new Label
        {
            Left = 370,
            Top = 20,
            Width = 440,
            Height = 28,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Text = "READY"
        };

        statusSection.Controls.Add(_entropyLabel);
        statusSection.Controls.Add(_statusLabel);

        tab.Controls.Add(inputSection);
        tab.Controls.Add(generatorSection);
        tab.Controls.Add(statusSection);

        return tab;
    }

    private TabPage BuildPasswordListTab()
    {
        TabPage tab = new("Password List");

        GroupBox listSection = Section("Saved Password List", 16, 16, 855, 390);

        _passwordGrid = new DataGridView
        {
            Left = 18,
            Top = 30,
            Width = 815,
            Height = 335,
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        };

        listSection.Controls.Add(_passwordGrid);

        Button copyButton = new() { Text = "COPY", Left = 16, Top = 420, Width = 100 };
        copyButton.Click += (_, _) => CopySelectedPassword();

        Button editButton = new() { Text = "EDIT", Left = 126, Top = 420, Width = 100 };
        editButton.Click += (_, _) => EditSelectedEntry();

        Button deleteButton = new() { Text = "DELETE", Left = 236, Top = 420, Width = 100 };
        deleteButton.Click += (_, _) => DeleteSelectedEntry();

        Button refreshButton = new() { Text = "REFRESH", Left = 346, Top = 420, Width = 100 };
        refreshButton.Click += (_, _) => RefreshPasswordList();

        Label warning = new()
        {
            Text = "Saved files are encrypted with Windows DPAPI for the current Windows user.",
            Left = 16,
            Top = 465,
            Width = 760,
            Height = 30
        };

        tab.Controls.Add(listSection);
        tab.Controls.Add(copyButton);
        tab.Controls.Add(editButton);
        tab.Controls.Add(deleteButton);
        tab.Controls.Add(refreshButton);
        tab.Controls.Add(warning);

        return tab;
    }

    private TabPage BuildSavedFilesTab()
    {
        TabPage tab = new("Saved Files");

        GroupBox folderSection = Section("Save Location", 16, 16, 855, 100);

        Label folderLabel = new() { Text = "Folder", Left = 18, Top = 38, Width = 100 };
        _saveFolderBox = new TextBox { Left = 120, Top = 35, Width = 560, ReadOnly = true };

        Button chooseButton = new() { Text = "SELECT", Left = 695, Top = 34, Width = 90 };
        chooseButton.Click += (_, _) => ChooseSaveFolder();

        Button openButton = new() { Text = "OPEN", Left = 790, Top = 34, Width = 55 };
        openButton.Click += (_, _) => PasswordStore.OpenFolder(_settings.SaveFolder);

        folderSection.Controls.Add(folderLabel);
        folderSection.Controls.Add(_saveFolderBox);
        folderSection.Controls.Add(chooseButton);
        folderSection.Controls.Add(openButton);

        GroupBox filesSection = Section("Files", 16, 135, 855, 315);
        _fileList = new ListBox { Left = 18, Top = 30, Width = 815, Height = 260 };
        filesSection.Controls.Add(_fileList);

        Button refreshButton = new() { Text = "REFRESH", Left = 16, Top = 465, Width = 100 };
        refreshButton.Click += (_, _) => RefreshFileList();

        tab.Controls.Add(folderSection);
        tab.Controls.Add(filesSection);
        tab.Controls.Add(refreshButton);

        return tab;
    }

    private TabPage BuildOptionsTab()
    {
        TabPage tab = new("Options");

        GroupBox accessibility = Section("Accessibility", 16, 16, 855, 120);
        _ttsCheck = new CheckBox { Text = "Enable text-to-speech status messages", Left = 18, Top = 35, Width = 320 };
        _ttsCheck.CheckedChanged += (_, _) =>
        {
            _settings.TextToSpeechEnabled = _ttsCheck.Checked;
            SettingsService.Save(_settings);
        };

        Button testSpeechButton = new() { Text = "TEST", Left = 350, Top = 32, Width = 80 };
        testSpeechButton.Click += (_, _) => SpeechService.SpeakIfEnabled(_settings, "SecurePassGenSaver text to speech is enabled.");

        accessibility.Controls.Add(_ttsCheck);
        accessibility.Controls.Add(testSpeechButton);

        GroupBox dataSection = Section("Data Management", 16, 155, 855, 165);

        Button deleteDataButton = new() { Text = "DELETE ALL SAVED PASSWORD FILES", Left = 18, Top = 35, Width = 280 };
        deleteDataButton.Click += (_, _) => DeleteAllSavedData();

        Button resetSettingsButton = new() { Text = "RESET APP SETTINGS", Left = 18, Top = 80, Width = 280 };
        resetSettingsButton.Click += (_, _) => ResetSettings();

        Label deleteNote = new()
        {
            Text = "The app cannot safely uninstall itself. To remove it, delete the published folder or uninstall it through Windows if you create an installer.",
            Left = 320,
            Top = 38,
            Width = 500,
            Height = 75
        };

        dataSection.Controls.Add(deleteDataButton);
        dataSection.Controls.Add(resetSettingsButton);
        dataSection.Controls.Add(deleteNote);

        tab.Controls.Add(accessibility);
        tab.Controls.Add(dataSection);

        return tab;
    }

    private TabPage BuildSettingsTab()
    {
        TabPage tab = new("Settings");

        GroupBox appearance = Section("Appearance", 16, 16, 855, 100);
        Label themeLabel = new() { Text = "Theme", Left = 18, Top = 38, Width = 100 };

        _themeCombo = new ComboBox { Left = 120, Top = 35, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        _themeCombo.Items.AddRange(new object[] { "Dark", "Light", "System" });
        _themeCombo.SelectedIndexChanged += (_, _) =>
        {
            _settings.Theme = _themeCombo.SelectedItem?.ToString() ?? "Dark";
            SettingsService.Save(_settings);
            ApplyCurrentTheme();
        };

        appearance.Controls.Add(themeLabel);
        appearance.Controls.Add(_themeCombo);

        GroupBox pinSection = Section("App PIN Lock", 16, 135, 855, 245);

        Label warning = new()
        {
            Text = "Saved files are encrypted with Windows DPAPI. The app PIN protects app access.",
            Left = 18,
            Top = 30,
            Width = 700,
            Height = 25
        };

        _pinEnabledCheck = new CheckBox { Text = "Enable 4-digit PIN", Left = 18, Top = 65, Width = 180 };

        Label pinLabel = new() { Text = "PIN", Left = 18, Top = 105, Width = 100 };
        _pinBox = new TextBox { Left = 120, Top = 102, Width = 140, MaxLength = 4, PasswordChar = '●' };

        Label confirmLabel = new() { Text = "Confirm PIN", Left = 18, Top = 145, Width = 100 };
        _pinConfirmBox = new TextBox { Left = 120, Top = 142, Width = 140, MaxLength = 4, PasswordChar = '●' };

        Label hintLabel = new() { Text = "Hint", Left = 300, Top = 105, Width = 80 };
        _pinHintBox = new TextBox { Left = 385, Top = 102, Width = 330 };

        Button savePinButton = new() { Text = "SAVE PIN", Left = 120, Top = 185, Width = 110 };
        savePinButton.Click += (_, _) => SavePinSettings();

        Button disablePinButton = new() { Text = "DISABLE PIN", Left = 240, Top = 185, Width = 120 };
        disablePinButton.Click += (_, _) => DisablePin();

        pinSection.Controls.Add(warning);
        pinSection.Controls.Add(_pinEnabledCheck);
        pinSection.Controls.Add(pinLabel);
        pinSection.Controls.Add(_pinBox);
        pinSection.Controls.Add(confirmLabel);
        pinSection.Controls.Add(_pinConfirmBox);
        pinSection.Controls.Add(hintLabel);
        pinSection.Controls.Add(_pinHintBox);
        pinSection.Controls.Add(savePinButton);
        pinSection.Controls.Add(disablePinButton);

        tab.Controls.Add(appearance);
        tab.Controls.Add(pinSection);

        return tab;
    }

    private TabPage BuildAboutTab()
    {
        TabPage tab = new("?");

        GroupBox info = Section("Information", 16, 16, 855, 455);
        TextBox aboutBox = new()
        {
            Left = 18,
            Top = 30,
            Width = 815,
            Height = 395,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Text =
@"SecurePassGenSaver

SecurePassGenSaver is an open-source password generator made with C# and Windows Forms.

Random generation:
- Passwords are generated locally on your computer.
- The app uses RandomNumberGenerator from .NET.
- No internet connection is required.
- No passwords are sent anywhere.
- No tracking or analytics are included.

Privacy:
- Generated passwords stay on your device.
- Saved files use Windows DPAPI encryption and are tied to the current Windows user account.
- The app PIN protects app access. Saved files are encrypted separately with Windows DPAPI.

Portfolio purpose:
This project demonstrates C# programming, Windows Forms UI design, random password generation, entropy estimation, local file storage, and basic cybersecurity awareness."
        };

        info.Controls.Add(aboutBox);
        tab.Controls.Add(info);

        return tab;
    }

    private PasswordGeneratorOptions CurrentOptions()
    {
        return new PasswordGeneratorOptions
        {
            Length = _lengthSlider.Value,
            UseLowercase = _lowercaseCheck.Checked,
            UseUppercase = _uppercaseCheck.Checked,
            UseNumbers = _numbersCheck.Checked,
            UseSymbols = _symbolsCheck.Checked,
            AvoidAmbiguous = _ambiguousCheck.Checked
        };
    }

    private void GeneratePassword()
    {
        PasswordGeneratorOptions options = CurrentOptions();
        string password = PasswordGenerator.Generate(options);
        _passwordBox.Text = password;

        double entropy = PasswordGenerator.CalculateEntropy(options);
        _statusLabel.Text = $"GENERATED - {PasswordGenerator.StrengthLabel(entropy)}";
        SpeechService.SpeakIfEnabled(_settings, "Password generated.");
    }

    private void SaveCurrentPassword()
    {
        if (string.IsNullOrWhiteSpace(_passwordBox.Text))
        {
            MessageBox.Show("Generate a password first.", "Missing Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        PasswordEntry entry = new()
        {
            SaveName = string.IsNullOrWhiteSpace(_saveNameBox.Text) ? "password" : _saveNameBox.Text.Trim(),
            Username = _usernameBox.Text.Trim(),
            Password = _passwordBox.Text,
            CreatedLocal = DateTime.Now
        };

        PasswordStore.SaveEntry(_settings.SaveFolder, entry);
        RefreshPasswordList();
        RefreshFileList();
        _statusLabel.Text = "SAVED";
        SpeechService.SpeakIfEnabled(_settings, "Password saved.");
    }

    private void CopyGeneratedPassword()
    {
        if (!string.IsNullOrWhiteSpace(_passwordBox.Text))
        {
            Clipboard.SetText(_passwordBox.Text);
            _statusLabel.Text = "COPIED";
        }
    }

    private void CopySelectedPassword()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        Clipboard.SetText(entry.Password);
        MessageBox.Show("Password copied to clipboard.", "Copied", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void EditSelectedEntry()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        using EditEntryForm form = new(entry);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            PasswordStore.SaveEntry(_settings.SaveFolder, form.Entry);
            RefreshPasswordList();
            RefreshFileList();
        }
    }

    private void DeleteSelectedEntry()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        DialogResult result = MessageBox.Show("Delete this saved password file?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        PasswordStore.DeleteEntry(entry);
        RefreshPasswordList();
        RefreshFileList();
    }

    private PasswordEntry? SelectedEntry()
    {
        if (_passwordGrid.CurrentRow?.DataBoundItem is PasswordEntry entry)
        {
            return entry;
        }

        MessageBox.Show("Select a saved password first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return null;
    }

    private void RefreshPasswordList()
    {
        List<PasswordEntry> entries = PasswordStore.LoadEntries(_settings.SaveFolder);
        _passwordGrid.DataSource = null;
        _passwordGrid.DataSource = entries;

        if (_passwordGrid.Columns["Password"] != null)
        {
            _passwordGrid.Columns["Password"].Visible = false;
        }

        if (_passwordGrid.Columns["FilePath"] != null)
        {
            _passwordGrid.Columns["FilePath"].Visible = false;
        }
    }

    private void RefreshFileList()
    {
        Directory.CreateDirectory(_settings.SaveFolder);
        _saveFolderBox.Text = _settings.SaveFolder;

        _fileList.Items.Clear();
        foreach (string file in Directory.GetFiles(_settings.SaveFolder, "*.spgs").Concat(Directory.GetFiles(_settings.SaveFolder, "*.md")).OrderByDescending(File.GetCreationTime))
        {
            _fileList.Items.Add(Path.GetFileName(file));
        }
    }

    private void ChooseSaveFolder()
    {
        using FolderBrowserDialog dialog = new()
        {
            Description = "Choose a folder or flash drive to save password files"
        };

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            _settings.SaveFolder = dialog.SelectedPath;
            SettingsService.Save(_settings);
            RefreshPasswordList();
            RefreshFileList();
        }
    }

    private void DeleteAllSavedData()
    {
        DialogResult result = MessageBox.Show("Delete ALL saved password files in the current save folder?", "Danger", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        PasswordStore.DeleteAll(_settings.SaveFolder);
        RefreshPasswordList();
        RefreshFileList();
        MessageBox.Show("Saved password files deleted.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void ResetSettings()
    {
        DialogResult result = MessageBox.Show("Reset app settings and disable PIN?", "Confirm Reset", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        SettingsService.Reset();
        _settings = SettingsService.Load();
        LoadSettingsToControls();
        ApplyCurrentTheme();
        RefreshPasswordList();
        RefreshFileList();
    }

    private void SavePinSettings()
    {
        if (!_pinEnabledCheck.Checked)
        {
            DisablePin();
            return;
        }

        string pin = _pinBox.Text.Trim();
        string confirm = _pinConfirmBox.Text.Trim();

        if (!PinManager.IsValidPinFormat(pin))
        {
            MessageBox.Show("PIN must be exactly 4 digits.", "Invalid PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (pin != confirm)
        {
            MessageBox.Show("PIN confirmation does not match.", "Invalid PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        PinManager.SetPin(_settings, pin, _pinHintBox.Text);
        SettingsService.Save(_settings);
        MessageBox.Show("PIN enabled.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

        _pinBox.Clear();
        _pinConfirmBox.Clear();
    }

    private void DisablePin()
    {
        PinManager.DisablePin(_settings);
        SettingsService.Save(_settings);
        _pinEnabledCheck.Checked = false;
        _pinBox.Clear();
        _pinConfirmBox.Clear();
        _pinHintBox.Clear();
        MessageBox.Show("PIN disabled.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void LoadSettingsToControls()
    {
        _ttsCheck.Checked = _settings.TextToSpeechEnabled;

        _themeCombo.SelectedItem = _settings.Theme;
        if (_themeCombo.SelectedItem == null)
        {
            _themeCombo.SelectedItem = "Dark";
        }

        _pinEnabledCheck.Checked = _settings.PinEnabled;
        _pinHintBox.Text = _settings.PinHint;
        _saveFolderBox.Text = _settings.SaveFolder;
    }

    private void ApplyCurrentTheme()
    {
        bool dark = _settings.Theme != "Light";

        if (dark)
        {
            Theme.ApplyDark(this);
            _lengthBubble.BackColor = Color.FromArgb(55, 55, 55);
            _lengthBubble.ForeColor = Color.WhiteSmoke;
        }
        else
        {
            Theme.ApplyLight(this);
            _lengthBubble.BackColor = Color.White;
            _lengthBubble.ForeColor = Color.Black;
        }

        _tabs.DarkMode = dark;
        _tabs.Invalidate();
        UpdateLengthAndEntropy();
    }

    private void UpdateLengthAndEntropy()
    {
        if (_lengthBubble == null || _entropyLabel == null || _lengthSlider == null)
        {
            return;
        }

        _lengthBubble.Text = _lengthSlider.Value.ToString();
        MoveLengthBubble();

        PasswordGeneratorOptions options = CurrentOptions();
        double entropy = PasswordGenerator.CalculateEntropy(options);
        _entropyLabel.Text = $"Length: {_lengthSlider.Value} characters | Entropy: {entropy:0.00} bits | {PasswordGenerator.StrengthLabel(entropy)}";
    }

    private void MoveLengthBubble()
    {
        int min = _lengthSlider.Minimum;
        int max = _lengthSlider.Maximum;
        int value = _lengthSlider.Value;

        double percent = (value - min) / (double)(max - min);

        int usableWidth = _lengthSlider.Width - 32;
        int x = _lengthSlider.Left + 16 + (int)(usableWidth * percent) - (_lengthBubble.Width / 2);

        int minX = _lengthSlider.Left;
        int maxX = _lengthSlider.Right - _lengthBubble.Width;

        if (x < minX) x = minX;
        if (x > maxX) x = maxX;

        _lengthBubble.Left = x;
    }
}
