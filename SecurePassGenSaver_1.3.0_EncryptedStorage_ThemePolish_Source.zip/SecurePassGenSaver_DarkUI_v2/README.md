# SecurePassGenSaver

SecurePassGenSaver is an open-source C# Windows desktop password generator with a compact dark utility-style interface inspired by practical tools like Rufus and OpenRGB.

## Features

- Dark Windows Forms interface
- Custom themed tab bar
- Floating password length number above the slider
- Generate passwords locally
- Uses `.NET RandomNumberGenerator`
- Choose password length from 8 to 32 characters
- Include/exclude:
  - lowercase letters
  - uppercase letters
  - numbers
  - special characters
- Avoid ambiguous characters like `I`, `l`, `1`, `O`, and `0`
- Save passwords as Markdown files
- Choose a save folder, including a USB flash drive
- View saved password list
- Copy, edit, and delete saved entries
- Open saved files folder
- Accessibility text-to-speech option
- Dark/light/system theme setting
- Optional 4-digit app PIN with hint
- Help tab explaining privacy and offline generation

## Important Security Note

Saved password files are stored as readable Markdown plain text.  
The 4-digit app PIN only protects app access. It does not encrypt the saved files.

For real-world password storage, use a trusted password manager.

## How to Run

Install the .NET 8 SDK, then run:

```bash
dotnet run
```

## How to Build a Windows EXE

```bash
dotnet publish -c Release -r win-x64 --self-contained false /p:PublishSingleFile=true
```

The executable will be created in:

```text
bin/Release/net8.0-windows/win-x64/publish/
```

## Portfolio Purpose

This project was created as a beginner cybersecurity and programming portfolio project.  
It demonstrates C# programming, Windows Forms UI design, random password generation, entropy estimation, local file storage, basic privacy awareness, and project documentation.

## License

MIT License.


## Windows Installer

This project includes installer files in the `Installer` and `Scripts` folders.

To build a setup `.exe`:

```powershell
.\Scripts\build-publish.ps1
```

Then open:

```text
Installer\SecurePassGenSaver.iss
```

in Inno Setup and press **Compile**.

The installer will install the app into `C:\Program Files\SecurePassGenSaver`, create a desktop shortcut, create a Start Menu shortcut, and make the app searchable from Windows Search.


## Single EXE Build

To avoid distributing a folder full of `.dll` files, build the app as a self-contained single-file EXE:

```powershell
.\Scripts\build-single-exe.ps1
```

The output will be:

```text
Publish\SecurePassGenSaver.exe
```

For public users, the recommended download is the setup installer:

```text
SecurePassGenSaver-1.3.0-Setup.exe
```

The installer places the app in `C:\Program Files\SecurePassGenSaver`, creates Desktop and Start Menu shortcuts, and makes the app searchable from Windows Search.


## Application Icon and Shortcuts

SecurePassGenSaver includes a custom key-and-tag application icon located at:

```text
Assets\SecurePassGenSaver.ico
```

The project file uses this icon for the built `.exe`.

The installer also uses the same icon for:

- the setup file
- the installed application
- the desktop shortcut
- the Start Menu shortcut

After installing, users can search for `SecurePassGenSaver` in Windows Search.

To pin it to the taskbar:

1. Open Start.
2. Search for `SecurePassGenSaver`.
3. Right-click it.
4. Select `Pin to taskbar`.

To pin it to Start:

1. Open Start.
2. Search for `SecurePassGenSaver`.
3. Right-click it.
4. Select `Pin to Start`.


## 1.3.0 Theme Fix

Version 1.3.0 includes a light theme fix so that group boxes, labels, status areas, and other controls switch correctly between dark and light themes. This keeps the interface consistent when users choose the Light theme.


## SecurePassGenSaver 1.3.0 — Encrypted Storage Update

Version 1.3.0 adds encrypted password storage using Windows DPAPI.

Saved passwords are now stored in `.spgs` files. These files are encrypted for the current Windows user account.

### What changed

- Added Windows DPAPI encrypted storage
- Added `.spgs` encrypted save format
- Legacy `.md` password files can still be read
- Re-saving a legacy entry converts it to encrypted storage
- Improved light theme polish
- Improved theme consistency across controls
- Updated security warnings

### Important

Windows Defender does not encrypt these files.  
The encryption is done through Windows DPAPI, which is built into Windows.
