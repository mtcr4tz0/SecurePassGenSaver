namespace SecurePassGenSaver;

public static class Theme
{
    public static readonly Color DarkBack = Color.FromArgb(32, 32, 32);
    public static readonly Color DarkPanel = Color.FromArgb(46, 46, 46);
    public static readonly Color DarkControl = Color.FromArgb(55, 55, 55);
    public static readonly Color DarkBorder = Color.FromArgb(95, 95, 95);
    public static readonly Color DarkText = Color.WhiteSmoke;

    public static readonly Color LightBack = Color.FromArgb(245, 246, 248);
    public static readonly Color LightPanel = Color.White;
    public static readonly Color LightControl = Color.White;
    public static readonly Color LightBorder = Color.FromArgb(190, 195, 205);
    public static readonly Color LightText = Color.FromArgb(25, 25, 25);

    public static void ApplyDark(Control root)
    {
        ApplyThemeRecursive(root, dark: true);
    }

    public static void ApplyLight(Control root)
    {
        ApplyThemeRecursive(root, dark: false);
    }

    private static void ApplyThemeRecursive(Control control, bool dark)
    {
        Color rootBack = dark ? DarkBack : LightBack;
        Color panelBack = dark ? DarkBack : LightPanel;
        Color inputBack = dark ? DarkControl : LightControl;
        Color text = dark ? DarkText : LightText;
        Color border = dark ? DarkBorder : LightBorder;
        Color gridHeader = dark ? Color.FromArgb(42, 42, 42) : Color.FromArgb(235, 238, 243);
        Color selectionBack = dark ? Color.FromArgb(80, 80, 80) : Color.FromArgb(0, 120, 215);
        Color selectionFore = dark ? DarkText : Color.White;

        if (control is Form or control is TabPage)
        {
            control.BackColor = rootBack;
            control.ForeColor = text;
        }
        else if (control is GroupBox groupBox)
        {
            groupBox.BackColor = rootBack;
            groupBox.ForeColor = text;
        }
        else if (control is Panel)
        {
            control.BackColor = panelBack;
            control.ForeColor = text;
        }
        else if (control is Label)
        {
            control.BackColor = Color.Transparent;
            control.ForeColor = text;
        }
        else if (control is CheckBox)
        {
            control.BackColor = Color.Transparent;
            control.ForeColor = text;
        }
        else if (control is TextBox textBox)
        {
            textBox.BackColor = inputBack;
            textBox.ForeColor = text;
            textBox.BorderStyle = BorderStyle.FixedSingle;
        }
        else if (control is ComboBox comboBox)
        {
            comboBox.BackColor = inputBack;
            comboBox.ForeColor = text;
        }
        else if (control is Button button)
        {
            button.ForeColor = text;

            if (dark)
            {
                button.BackColor = DarkControl;
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = border;
                button.FlatAppearance.BorderSize = 1;
            }
            else
            {
                button.BackColor = Color.FromArgb(250, 250, 250);
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = border;
                button.FlatAppearance.BorderSize = 1;
            }
        }
        else if (control is ThemedTabControl themedTabs)
        {
            themedTabs.DarkMode = dark;
            themedTabs.BackColor = rootBack;
            themedTabs.ForeColor = text;
            themedTabs.Invalidate();
        }
        else if (control is ListBox listBox)
        {
            listBox.BackColor = inputBack;
            listBox.ForeColor = text;
            listBox.BorderStyle = BorderStyle.FixedSingle;
        }
        else if (control is DataGridView grid)
        {
            grid.BackgroundColor = inputBack;
            grid.GridColor = border;
            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = gridHeader;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = text;
            grid.DefaultCellStyle.BackColor = inputBack;
            grid.DefaultCellStyle.ForeColor = text;
            grid.DefaultCellStyle.SelectionBackColor = selectionBack;
            grid.DefaultCellStyle.SelectionForeColor = selectionFore;
            grid.RowHeadersDefaultCellStyle.BackColor = gridHeader;
            grid.RowHeadersDefaultCellStyle.ForeColor = text;
        }
        else if (control is TrackBar)
        {
            control.BackColor = rootBack;
            control.ForeColor = text;
        }
        else
        {
            control.BackColor = rootBack;
            control.ForeColor = text;
        }

        foreach (Control child in control.Controls)
        {
            ApplyThemeRecursive(child, dark);
        }
    }
}
