$ErrorActionPreference = "Stop"

Write-Host "Building SecurePassGenSaver 1.4.2 as a self-contained portable single-file EXE..." -ForegroundColor Cyan

$projectRoot = Split-Path -Parent $PSScriptRoot
$publishDir = Join-Path $projectRoot "Publish"

if (Test-Path $publishDir) {
    Remove-Item $publishDir -Recurse -Force
}

dotnet restore "$projectRoot\SecurePassGenSaver.csproj"

dotnet publish "$projectRoot\SecurePassGenSaver.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained true `
    /p:PublishSingleFile=true `
    /p:IncludeNativeLibrariesForSelfExtract=true `
    /p:EnableCompressionInSingleFile=true `
    /p:PublishTrimmed=false `
    /p:DebugType=None `
    /p:DebugSymbols=false `
    -o "$publishDir"

Write-Host ""
Write-Host "Build complete." -ForegroundColor Green
Write-Host "Portable EXE:"
Write-Host "$publishDir\SecurePassGenSaver.exe"
