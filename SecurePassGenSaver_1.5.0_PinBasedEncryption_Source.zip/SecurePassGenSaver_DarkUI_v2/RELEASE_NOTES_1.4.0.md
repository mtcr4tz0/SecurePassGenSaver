# SecurePassGenSaver 1.4.0 — Portable Release and OpenRGB-Style UI Polish

Version 1.4.0 improves the app in two major ways:

1. The app now builds as a self-contained portable single-file EXE.
2. The Generate page has been redesigned with a compact utility layout inspired by OpenRGB-style Windows tools.

## Portable EXE Fix

Earlier framework-dependent builds could fail if users copied or dragged only the `.exe` to another folder.

Version 1.4.0 fixes this by making the main build self-contained:

```text
Publish\SecurePassGenSaver.exe
```

This portable EXE can be moved to another folder and launched by itself.

## Installer

The installer still installs the app normally into:

```text
C:\Program Files\SecurePassGenSaver
```

and creates Start Menu / Desktop shortcuts.

The final setup file is:

```text
InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe
```

## UI Changes

- Redesigned Generate tab with an OpenRGB-style utility layout
- Added left saved-entry panel
- Added central password configuration panel
- Added right security information panel
- Added bottom action controls
- Improved spacing and layout balance
- Kept dark/light theme support
- Kept Windows DWM title bar styling

## Security

- Saved files remain encrypted with Windows DPAPI
- Encrypted save format remains `.spgs`
- Legacy `.md` files can still be read
