# SecurePassGenSaver 1.5.0 — PIN-Based Encryption Upgrade

Version 1.5.0 fixes the security weakness where deleting the settings file could remove the app PIN while DPAPI-only files were still decryptable by the same Windows user.

## Main Security Change

When a PIN is enabled, saved `.spgs` files are now encrypted using:

- PBKDF2-SHA256 key derivation
- 250,000 iterations
- AES-GCM encryption
- random salt per file
- random nonce per file

This means the PIN is now required to decrypt PIN-protected saved password files.

## Why This Matters

Previous versions used:

```text
PIN = app lock
DPAPI = file encryption
```

Version 1.5.0 changes the protection model to:

```text
PIN = app lock + file decryption key
```

Deleting the app settings file no longer unlocks PIN-encrypted password files.

## Migration

When you save a PIN, the app tries to migrate existing readable entries into the new PIN-based encrypted format.

Legacy files are still supported:

- old `.md` files can still be read
- older DPAPI `.spgs` files can still be read by the same Windows account
- after enabling a PIN, readable entries are re-saved with PIN-based encryption

## Important

If you forget the PIN for PIN-encrypted files, those saved passwords cannot be recovered. That is the tradeoff of real encryption.
