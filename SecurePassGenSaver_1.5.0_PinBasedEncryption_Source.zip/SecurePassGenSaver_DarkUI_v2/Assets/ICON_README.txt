Put your app icon here as:

SecurePassGenSaver.ico

The installer script expects:
Assets\SecurePassGenSaver.ico

If you do not have an icon yet, remove or comment out this line from Installer\SecurePassGenSaver.iss:

SetupIconFile=..\Assets\SecurePassGenSaver.ico
