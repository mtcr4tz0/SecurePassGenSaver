namespace SecurePassGenSaver;

public static class AppIconHelper
{
    public static void Apply(Form form)
    {
        try
        {
            Icon? icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            if (icon != null)
            {
                form.Icon = icon;
            }
        }
        catch
        {
            // If the icon cannot be extracted, keep the default icon.
        }
    }
}
