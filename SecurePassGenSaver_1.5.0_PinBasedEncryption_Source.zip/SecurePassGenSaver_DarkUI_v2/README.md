# SecurePassGenSaver

## For Normal Users

Download the setup installer from GitHub Releases:

```text
SecurePassGenSaver-1.3.0-Setup.exe
```

Do not download the source code folder unless you want to build or edit the project.

## For Developers: Build the Installer

Install:

- .NET 8 SDK
- Inno Setup

Then double-click:

```text
BUILD_SETUP.bat
```

The final installer will be created at:

```text
InstallerOutput\SecurePassGenSaver-1.3.0-Setup.exe
```

This is the file that behaves like a normal Windows setup installer.


SecurePassGenSaver is an open-source C# Windows desktop password generator with a compact dark utility-style interface inspired by practical tools like Rufus and OpenRGB.

## Features

- Dark Windows Forms interface
- Custom themed tab bar
- Floating password length number above the slider
- Generate passwords locally
- Uses `.NET RandomNumberGenerator`
- Choose password length from 8 to 32 characters
- Include/exclude:
  - lowercase letters
  - uppercase letters
  - numbers
  - special characters
- Avoid ambiguous characters like `I`, `l`, `1`, `O`, and `0`
- Save passwords as Markdown files
- Choose a save folder, including a USB flash drive
- View saved password list
- Copy, edit, and delete saved entries
- Open saved files folder
- Accessibility text-to-speech option
- Dark/light/system theme setting
- Optional 4-digit app PIN with hint
- Help tab explaining privacy and offline generation

## Important Security Note

Saved password files are stored as readable Markdown plain text.  
The 4-digit app PIN only protects app access. It does not encrypt the saved files.

For real-world password storage, use a trusted password manager.

## How to Run

Install the .NET 8 SDK, then run:

```bash
dotnet run
```

## How to Build a Windows EXE

```bash
dotnet publish -c Release -r win-x64 --self-contained false /p:PublishSingleFile=true
```

The executable will be created in:

```text
bin/Release/net8.0-windows/win-x64/publish/
```

## Portfolio Purpose

This project was created as a beginner cybersecurity and programming portfolio project.  
It demonstrates C# programming, Windows Forms UI design, random password generation, entropy estimation, local file storage, basic privacy awareness, and project documentation.

## License

MIT License.


## Windows Installer

This project includes installer files in the `Installer` and `Scripts` folders.

To build a setup `.exe`:

```powershell
.\Scripts\build-publish.ps1
```

Then open:

```text
Installer\SecurePassGenSaver.iss
```

in Inno Setup and press **Compile**.

The installer will install the app into `C:\Program Files\SecurePassGenSaver`, create a desktop shortcut, create a Start Menu shortcut, and make the app searchable from Windows Search.


## Single EXE Build

To avoid distributing a folder full of `.dll` files, build the app as a self-contained single-file EXE:

```powershell
.\Scripts\build-single-exe.ps1
```

The output will be:

```text
Publish\SecurePassGenSaver.exe
```

For public users, the recommended download is the setup installer:

```text
SecurePassGenSaver-1.3.0-Setup.exe
```

The installer places the app in `C:\Program Files\SecurePassGenSaver`, creates Desktop and Start Menu shortcuts, and makes the app searchable from Windows Search.


## Application Icon and Shortcuts

SecurePassGenSaver includes a custom key-and-tag application icon located at:

```text
Assets\SecurePassGenSaver.ico
```

The project file uses this icon for the built `.exe`.

The installer also uses the same icon for:

- the setup file
- the installed application
- the desktop shortcut
- the Start Menu shortcut

After installing, users can search for `SecurePassGenSaver` in Windows Search.

To pin it to the taskbar:

1. Open Start.
2. Search for `SecurePassGenSaver`.
3. Right-click it.
4. Select `Pin to taskbar`.

To pin it to Start:

1. Open Start.
2. Search for `SecurePassGenSaver`.
3. Right-click it.
4. Select `Pin to Start`.


## 1.3.0 Theme Fix

Version 1.3.0 includes a light theme fix so that group boxes, labels, status areas, and other controls switch correctly between dark and light themes. This keeps the interface consistent when users choose the Light theme.


## SecurePassGenSaver 1.3.0 — Encrypted Storage Update

Version 1.3.0 adds encrypted password storage using Windows DPAPI.

Saved passwords are now stored in `.spgs` files. These files are encrypted for the current Windows user account.

### What changed

- Added Windows DPAPI encrypted storage
- Added `.spgs` encrypted save format
- Legacy `.md` password files can still be read
- Re-saving a legacy entry converts it to encrypted storage
- Improved light theme polish
- Improved theme consistency across controls
- Updated security warnings

### Important

Windows Defender does not encrypt these files.  
The encryption is done through Windows DPAPI, which is built into Windows.


## Build the OpenRGB-style Setup File

The source folder is for developers. Normal users should download the final setup installer.

To create the setup installer:

1. Install .NET 8 SDK.
2. Install Inno Setup.
3. Double-click:

```text
BUILD_SETUP.bat
```

The final installer will be created here:

```text
InstallerOutput\SecurePassGenSaver-1.3.0-Setup.exe
```

If the build fails, open:

```text
build_error.log
```

That file contains the exact error.


## Icon File

The app uses `Assets\SecurePassGenSaver.ico` for the EXE, installer, desktop shortcut, and Start Menu shortcut. The large PNG source icon was removed to keep the repository smaller.


## Build Fix

`BUILD_SETUP.bat` now uses a framework-dependent single-file build without bundle compression. This fixes:

```text
NETSDK1176: Compression in a single file bundle is only supported when publishing a self-contained application.
```

For a larger self-contained EXE, use:

```text
BUILD_SELF_CONTAINED_EXE.bat
```


## 1.3.0 Window Border and Builder Fix

This build improves native Windows theme behavior by using DWM APIs for the app title bar and border color.

It also fixes `BUILD_SETUP.bat` so it searches for the generated `.exe` and copies it into the `Publish` folder if .NET outputs it somewhere else.


## Taskbar Icon and Build Output

The app icon is applied both at the project level and at runtime, so the window and taskbar should use the custom key icon.

If Windows still shows the old/default icon, uninstall the old version, delete old shortcuts, unpin the old taskbar icon, reinstall, then pin the new shortcut again. Windows caches app icons.

After running `BUILD_SETUP.bat`:

```text
Publish\SecurePassGenSaver.exe
```

contains the built application.

```text
InstallerOutput\SecurePassGenSaver-1.3.0-Setup.exe
```

contains the final setup installer.


## SecurePassGenSaver 1.4.0 — Portable Release and UI Polish

Version 1.4.0 changes the main build to a self-contained portable single-file EXE. This means the file in `Publish\SecurePassGenSaver.exe` can be moved to another folder and launched by itself.

The setup installer is still the recommended download for normal users.

### Build

Double-click:

```text
BUILD_SETUP.bat
```

Outputs:

```text
Publish\SecurePassGenSaver.exe
InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe
```

### UI

The Generate tab has been redesigned into a compact utility-style layout inspired by OpenRGB-like Windows tools:

- saved entries panel
- password configuration panel
- security information panel
- status panel
- action buttons


## SecurePassGenSaver 1.4.1 — Builder Patch

Version 1.4.1 fixes the build script so the portable EXE is reliably created in:

```text
Publish\SecurePassGenSaver.exe
```

and the installer is created in:

```text
InstallerOutput\SecurePassGenSaver-1.4.1-Setup.exe
```

Run:

```text
BUILD_SETUP.bat
```


## Final UI Polish

The Information tab now uses a cleaner layout with readable sections for overview, security, portable release notes, and the final disclaimer.


## SecurePassGenSaver 1.4.2 — PIN Save Fix

Version 1.4.2 fixes a PIN settings issue.

Previously, clicking **Save PIN** while the checkbox was unchecked could disable the PIN instead of saving it. Now, entering a valid 4-digit PIN and clicking **Save PIN** automatically enables and saves the PIN.

Use **Disable PIN** only when you actually want to turn the PIN off.


## SecurePassGenSaver 1.5.0 — PIN-Based Encryption Upgrade

Version 1.5.0 changes the security model.

Older versions used the PIN mainly as an app lock. Version 1.5.0 uses the PIN as part of file encryption when PIN protection is enabled.

### New encryption behavior

When a PIN is enabled, saved `.spgs` files use:

- PBKDF2-SHA256
- 250,000 iterations
- AES-GCM encryption
- random salt per file
- random nonce per file

This means deleting the settings file does not unlock PIN-encrypted files.

### Important warning

If you forget the PIN, PIN-encrypted saved passwords cannot be recovered.
