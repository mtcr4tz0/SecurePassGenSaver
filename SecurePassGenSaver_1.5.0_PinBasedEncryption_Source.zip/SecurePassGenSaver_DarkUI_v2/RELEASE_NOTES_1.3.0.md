# SecurePassGenSaver 1.3.0 — Encrypted Storage and Theme Polish

SecurePassGenSaver 1.3.0 is a security and polish update.

## Main Change

Saved password files are now encrypted using Windows DPAPI instead of being saved as readable Markdown text.

DPAPI means the saved file is protected by the current Windows user account. A file encrypted by one Windows user normally cannot be decrypted by another Windows user or another PC.

## New Features

- Added Windows DPAPI encrypted password storage
- New encrypted save file format: `.spgs`
- Existing legacy `.md` files from older versions can still be read
- Editing or re-saving a legacy Markdown entry converts it into the encrypted `.spgs` format
- Updated security warnings inside the app
- Updated saved files list to show `.spgs` files

## Theme Improvements

- Improved light theme consistency
- Cleaner light background colors
- Better light theme button styling
- Better tab strip light theme colors
- Cleaner status and control text colors
- Fixed dark leftovers in light mode

## Important Notes

This app now encrypts saved password files using Windows DPAPI.

However, it is still an educational and portfolio project. For critical accounts, a trusted password manager is still recommended.

Windows Defender is not the encryption system used here. The encryption is handled by Windows DPAPI.
