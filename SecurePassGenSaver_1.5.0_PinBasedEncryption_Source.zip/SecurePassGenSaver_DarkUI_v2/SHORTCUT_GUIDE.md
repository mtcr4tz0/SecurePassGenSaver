# Shortcut and Pinning Guide

SecurePassGenSaver is configured like a normal Windows desktop app.

## What the installer creates

The installer creates:

- A Start Menu shortcut
- An optional Desktop shortcut
- An optional Quick Launch shortcut
- An uninstall entry in Windows settings

Because the app has a Start Menu shortcut, Windows Search can find it.

## How users can create a Desktop shortcut

During setup, leave this option enabled:

```text
Create a desktop shortcut
```

After installation, the shortcut will appear on the desktop.

## How users can pin to taskbar

After installing the app:

1. Click the Windows Start button.
2. Search for `SecurePassGenSaver`.
3. Right-click the app.
4. Choose `Pin to taskbar`.

## How users can pin to Start

1. Click the Windows Start button.
2. Search for `SecurePassGenSaver`.
3. Right-click the app.
4. Choose `Pin to Start`.

## How users can manually create a shortcut

1. Go to:

```text
C:\Program Files\SecurePassGenSaver
```

2. Right-click:

```text
SecurePassGenSaver.exe
```

3. Choose:

```text
Show more options > Send to > Desktop (create shortcut)
```

## Important note

Windows does not allow installers to reliably force-pin apps to the taskbar.  
The correct professional behavior is to create Start Menu and Desktop shortcuts, then let the user pin the app manually.
