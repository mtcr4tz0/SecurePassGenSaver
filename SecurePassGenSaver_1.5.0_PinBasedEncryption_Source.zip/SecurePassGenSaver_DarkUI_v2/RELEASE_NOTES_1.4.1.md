# SecurePassGenSaver 1.4.1 — Builder Patch

Version 1.4.1 fixes the release builder.

## Fixed

- `BUILD_SETUP.bat` now uses `-o Publish` instead of relying on `PublishDir`
- Cleans `bin` and `obj` before building
- Searches for the generated EXE if it is not exactly where expected
- Copies the EXE into `Publish\SecurePassGenSaver.exe`
- Creates `InstallerOutput\SecurePassGenSaver-1.4.1-Setup.exe`

## Output

Portable EXE:

```text
Publish\SecurePassGenSaver.exe
```

Setup installer:

```text
InstallerOutput\SecurePassGenSaver-1.4.1-Setup.exe
```
