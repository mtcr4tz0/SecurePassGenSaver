@echo off
setlocal EnableDelayedExpansion
title SecurePassGenSaver 1.5.0 Setup Builder
cd /d "%~dp0"

set "LOG=%~dp0build_error.log"
set "PROJECT=SecurePassGenSaver.csproj"
set "PUBLISH_DIR=%cd%\Publish"
set "SETUP_EXE=InstallerOutput\SecurePassGenSaver-1.5.0-Setup.exe"

echo ==============================================
echo SecurePassGenSaver 1.5.0 Setup Builder
echo ==============================================
echo.
echo WHERE THE FILES GO:
echo Portable EXE: Publish\SecurePassGenSaver.exe
echo Final installer: InstallerOutput\SecurePassGenSaver-1.5.0-Setup.exe
echo.
echo Build log:
echo %LOG%
echo.

if exist "%LOG%" del "%LOG%"

echo [1/4] Checking .NET SDK...
dotnet --version >nul 2>>"%LOG%"
if errorlevel 1 (
    echo ERROR: .NET SDK is not installed or dotnet is not in PATH.
    echo Install .NET 8 SDK or newer, then run this again.
    echo ERROR: dotnet command not found.>>"%LOG%"
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('dotnet --version') do set DOTNET_VERSION=%%i
echo .NET detected: %DOTNET_VERSION%
echo .NET detected: %DOTNET_VERSION%>>"%LOG%"

echo.
echo [2/4] Cleaning old build folders...
if exist "Publish" rmdir /s /q "Publish"
if exist "InstallerOutput" rmdir /s /q "InstallerOutput"
if exist "bin" rmdir /s /q "bin"
if exist "obj" rmdir /s /q "obj"
mkdir "Publish" >nul 2>&1

echo.
echo [3/4] Building self-contained portable single-file EXE...
echo.
echo This build can be moved to another folder and launched by itself.
echo.

dotnet restore "%PROJECT%" >>"%LOG%" 2>&1
if errorlevel 1 (
    echo ERROR: dotnet restore failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

dotnet publish "%PROJECT%" ^
    -c Release ^
    -r win-x64 ^
    --self-contained true ^
    /p:PublishSingleFile=true ^
    /p:IncludeNativeLibrariesForSelfExtract=true ^
    /p:EnableCompressionInSingleFile=true ^
    /p:PublishTrimmed=false ^
    /p:DebugType=None ^
    /p:DebugSymbols=false ^
    -o "%PUBLISH_DIR%" >>"%LOG%" 2>&1

if errorlevel 1 (
    echo ERROR: dotnet publish failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

echo.
echo Checking Publish folder...
dir /b "%PUBLISH_DIR%" >>"%LOG%" 2>&1

if not exist "Publish\SecurePassGenSaver.exe" (
    echo Publish\SecurePassGenSaver.exe not found. Searching for any generated EXE...
    echo Publish exe missing. Searching recursively...>>"%LOG%"

    set "FOUND_EXE="
    for /f "delims=" %%F in ('dir /b /s "*.exe" 2^>nul') do (
        echo Found candidate: %%F>>"%LOG%"
        echo %%F | findstr /i "SecurePassGenSaver" >nul
        if not errorlevel 1 (
            set "FOUND_EXE=%%F"
        )
    )

    if defined FOUND_EXE (
        echo Found:
        echo !FOUND_EXE!
        echo Copying to Publish\SecurePassGenSaver.exe
        copy /y "!FOUND_EXE!" "Publish\SecurePassGenSaver.exe" >>"%LOG%" 2>&1
    )
)

if not exist "Publish\SecurePassGenSaver.exe" (
    echo ERROR: The app EXE was not created.
    echo.
    echo Open build_error.log and send me the last 40 lines.
    echo.
    echo Last files found:
    dir /s /b *.exe
    echo.
    pause
    exit /b 1
)

echo Portable EXE ready:
echo %cd%\Publish\SecurePassGenSaver.exe
echo.

echo [4/4] Creating setup installer with Inno Setup...

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if "%ISCC%"=="" (
    echo.
    echo Inno Setup was not found.
    echo.
    echo The portable app EXE was built successfully:
    echo Publish\SecurePassGenSaver.exe
    echo.
    echo Install Inno Setup, then run this again to create the setup installer.
    echo.
    echo Inno Setup not found.>>"%LOG%"
    explorer "Publish"
    pause
    exit /b 0
)

"%ISCC%" "Installer\SecurePassGenSaver.iss" >>"%LOG%" 2>&1
if errorlevel 1 (
    echo ERROR: Inno Setup failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

if not exist "%SETUP_EXE%" (
    echo ERROR: Setup file was not created.
    echo Missing %SETUP_EXE%>>"%LOG%"
    pause
    exit /b 1
)

echo.
echo ==============================================
echo DONE
echo ==============================================
echo.
echo Portable EXE:
echo %cd%\Publish\SecurePassGenSaver.exe
echo.
echo Final installer:
echo %cd%\%SETUP_EXE%
echo.
echo Upload the setup file to GitHub Releases.
echo.
explorer "InstallerOutput"
pause
