namespace SecurePassGenSaver;

public class PasswordEntry
{
    public string SaveName { get; set; } = "";
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public DateTime CreatedLocal { get; set; } = DateTime.Now;
    public string FilePath { get; set; } = "";
}
