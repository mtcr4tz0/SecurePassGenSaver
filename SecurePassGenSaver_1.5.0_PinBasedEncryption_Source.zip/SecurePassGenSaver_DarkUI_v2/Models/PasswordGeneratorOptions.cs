namespace SecurePassGenSaver;

public class PasswordGeneratorOptions
{
    public int Length { get; set; } = 16;
    public bool UseLowercase { get; set; } = true;
    public bool UseUppercase { get; set; } = true;
    public bool UseNumbers { get; set; } = true;
    public bool UseSymbols { get; set; } = true;
    public bool AvoidAmbiguous { get; set; } = true;
}
