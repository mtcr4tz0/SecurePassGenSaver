namespace SecurePassGenSaver;

public class AppSettings
{
    public string SaveFolder { get; set; } = AppPaths.DefaultSaveFolder;
    public string Theme { get; set; } = "Dark";
    public bool TextToSpeechEnabled { get; set; } = false;

    public bool PinEnabled { get; set; } = false;
    public string PinSaltBase64 { get; set; } = "";
    public string PinHashBase64 { get; set; } = "";
    public string PinHint { get; set; } = "";
}
