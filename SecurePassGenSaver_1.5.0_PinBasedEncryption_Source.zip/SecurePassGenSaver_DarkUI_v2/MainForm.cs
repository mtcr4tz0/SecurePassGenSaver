namespace SecurePassGenSaver;

public class MainForm : Form
{
    private AppSettings _settings;

    private readonly ThemedTabControl _tabs = new();

    private ListBox _savedEntryList = new();
    private TextBox _saveNameBox = new();
    private TextBox _usernameBox = new();
    private TextBox _passwordBox = new();
    private TrackBar _lengthSlider = new();
    private Label _lengthBubble = new();
    private Label _entropyLabel = new();
    private Label _securitySummaryLabel = new();
    private Label _statusLabel = new();

    private CheckBox _lowercaseCheck = new();
    private CheckBox _uppercaseCheck = new();
    private CheckBox _numbersCheck = new();
    private CheckBox _symbolsCheck = new();
    private CheckBox _ambiguousCheck = new();

    private DataGridView _passwordGrid = new();
    private ListBox _fileList = new();
    private TextBox _saveFolderBox = new();

    private CheckBox _ttsCheck = new();
    private ComboBox _themeCombo = new();
    private CheckBox _pinEnabledCheck = new();
    private TextBox _pinBox = new();
    private TextBox _pinConfirmBox = new();
    private TextBox _pinHintBox = new();

    public MainForm()
    {
        _settings = SettingsService.Load();

        Text = "SecurePassGenSaver";
        AppIconHelper.Apply(this);

        StartPosition = FormStartPosition.CenterScreen;
        Width = 980;
        Height = 640;
        MinimumSize = new Size(940, 610);

        BuildTabs();
        Controls.Add(_tabs);

        RefreshAllLists();
        LoadSettingsToControls();
        ApplyCurrentTheme();
        UpdateLengthAndEntropy();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        AppIconHelper.Apply(this);
        DwmHelper.ApplyWindowTheme(this, _settings.Theme != "Light");
    }

    private GroupBox Section(string title, int left, int top, int width, int height)
    {
        return new GroupBox
        {
            Text = title,
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            Font = new Font(Font.FontFamily, 9, FontStyle.Bold)
        };
    }

    private Button UtilityButton(string text, int left, int top, int width = 110, int height = 28)
    {
        return new Button
        {
            Text = text,
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };
    }

    private Label FieldLabel(string text, int left, int top, int width = 120)
    {
        return new Label
        {
            Text = text,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };
    }

    private void BuildTabs()
    {
        _tabs.Dock = DockStyle.Fill;
        _tabs.TabPages.Add(BuildGenerateTab());
        _tabs.TabPages.Add(BuildPasswordListTab());
        _tabs.TabPages.Add(BuildSavedFilesTab());
        _tabs.TabPages.Add(BuildOptionsTab());
        _tabs.TabPages.Add(BuildSettingsTab());
        _tabs.TabPages.Add(BuildAboutTab());
    }

    private TabPage BuildGenerateTab()
    {
        TabPage tab = new("Generate");

        GroupBox savedPanel = Section("Saved Entries", 14, 14, 245, 485);
        _savedEntryList = new ListBox
        {
            Left = 14,
            Top = 26,
            Width = 215,
            Height = 370,
            DisplayMember = "SaveName"
        };
        _savedEntryList.DoubleClick += (_, _) => LoadSelectedSavedEntry();

        Button loadButton = UtilityButton("LOAD", 14, 408, 65);
        loadButton.Click += (_, _) => LoadSelectedSavedEntry();

        Button copySavedButton = UtilityButton("COPY", 84, 408, 65);
        copySavedButton.Click += (_, _) => CopySelectedPassword();

        Button deleteSavedButton = UtilityButton("DELETE", 154, 408, 75);
        deleteSavedButton.Click += (_, _) => DeleteSelectedEntry();

        Button refreshSavedButton = UtilityButton("REFRESH", 14, 443, 215);
        refreshSavedButton.Click += (_, _) => RefreshAllLists();

        savedPanel.Controls.Add(_savedEntryList);
        savedPanel.Controls.Add(loadButton);
        savedPanel.Controls.Add(copySavedButton);
        savedPanel.Controls.Add(deleteSavedButton);
        savedPanel.Controls.Add(refreshSavedButton);

        GroupBox configPanel = Section("Password Configuration", 270, 14, 445, 300);

        configPanel.Controls.Add(FieldLabel("Save name", 14, 32));
        _saveNameBox = new TextBox { Left = 135, Top = 31, Width = 285 };
        configPanel.Controls.Add(_saveNameBox);

        configPanel.Controls.Add(FieldLabel("Username", 14, 70));
        _usernameBox = new TextBox { Left = 135, Top = 69, Width = 285 };
        configPanel.Controls.Add(_usernameBox);

        configPanel.Controls.Add(FieldLabel("Password", 14, 108));
        _passwordBox = new TextBox { Left = 135, Top = 107, Width = 210, ReadOnly = true };
        Button copyButton = UtilityButton("COPY", 352, 106, 68, 25);
        copyButton.Click += (_, _) => CopyGeneratedPassword();
        configPanel.Controls.Add(_passwordBox);
        configPanel.Controls.Add(copyButton);

        configPanel.Controls.Add(FieldLabel("Length", 14, 153));
        _lengthBubble = new Label
        {
            Text = "16",
            Left = 0,
            Top = 137,
            Width = 46,
            Height = 24,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };

        _lengthSlider = new TrackBar
        {
            Left = 135,
            Top = 150,
            Width = 285,
            Minimum = 8,
            Maximum = 32,
            TickFrequency = 4,
            Value = 16,
            AutoSize = false,
            Height = 38
        };
        _lengthSlider.ValueChanged += (_, _) => UpdateLengthAndEntropy();

        Label minLabel = new() { Text = "8", Left = 135, Top = 185, Width = 30 };
        Label maxLabel = new() { Text = "32", Left = 390, Top = 185, Width = 30, TextAlign = ContentAlignment.MiddleRight };

        configPanel.Controls.Add(_lengthBubble);
        configPanel.Controls.Add(_lengthSlider);
        configPanel.Controls.Add(minLabel);
        configPanel.Controls.Add(maxLabel);

        _lowercaseCheck = new CheckBox { Text = "Lowercase", Left = 135, Top = 215, Width = 110, Checked = true };
        _uppercaseCheck = new CheckBox { Text = "Uppercase", Left = 260, Top = 215, Width = 110, Checked = true };
        _numbersCheck = new CheckBox { Text = "Numbers", Left = 135, Top = 242, Width = 110, Checked = true };
        _symbolsCheck = new CheckBox { Text = "Symbols", Left = 260, Top = 242, Width = 100, Checked = true };
        _ambiguousCheck = new CheckBox { Text = "Avoid I, l, 1, O, 0", Left = 135, Top = 269, Width = 210, Checked = true };

        _lowercaseCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _uppercaseCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _numbersCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _symbolsCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();
        _ambiguousCheck.CheckedChanged += (_, _) => UpdateLengthAndEntropy();

        configPanel.Controls.Add(_lowercaseCheck);
        configPanel.Controls.Add(_uppercaseCheck);
        configPanel.Controls.Add(_numbersCheck);
        configPanel.Controls.Add(_symbolsCheck);
        configPanel.Controls.Add(_ambiguousCheck);

        GroupBox securityPanel = Section("Security", 725, 14, 220, 300);

        Label encryptionTitle = FieldLabel("Storage", 14, 30, 180);
        Label encryptionValue = new() { Text = "PIN-based AES-GCM when PIN enabled", Left = 14, Top = 55, Width = 185, Height = 22 };
        Label formatTitle = FieldLabel("File format", 14, 90, 180);
        Label formatValue = new() { Text = ".spgs encrypted files", Left = 14, Top = 115, Width = 185, Height = 22 };
        Label portableTitle = FieldLabel("Release", 14, 150, 180);
        Label portableValue = new() { Text = "Self-contained portable EXE", Left = 14, Top = 175, Width = 190, Height = 22 };

        _securitySummaryLabel = new Label
        {
            Text = "READY",
            Left = 14,
            Top = 220,
            Width = 185,
            Height = 34,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };

        securityPanel.Controls.Add(encryptionTitle);
        securityPanel.Controls.Add(encryptionValue);
        securityPanel.Controls.Add(formatTitle);
        securityPanel.Controls.Add(formatValue);
        securityPanel.Controls.Add(portableTitle);
        securityPanel.Controls.Add(portableValue);
        securityPanel.Controls.Add(_securitySummaryLabel);

        GroupBox statusPanel = Section("Status", 270, 325, 675, 78);
        _entropyLabel = new Label
        {
            Left = 16,
            Top = 30,
            Width = 330,
            Height = 28,
            Text = "Entropy: -"
        };
        _statusLabel = new Label
        {
            Left = 360,
            Top = 25,
            Width = 295,
            Height = 34,
            Text = "READY",
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };
        statusPanel.Controls.Add(_entropyLabel);
        statusPanel.Controls.Add(_statusLabel);

        GroupBox actionsPanel = Section("Actions", 270, 417, 675, 82);
        Button generateButton = UtilityButton("GENERATE", 16, 32, 125);
        generateButton.Click += (_, _) => GeneratePassword();
        Button saveButton = UtilityButton("SAVE ENTRY", 151, 32, 125);
        saveButton.Click += (_, _) => SaveCurrentPassword();
        Button clearButton = UtilityButton("CLEAR", 286, 32, 100);
        clearButton.Click += (_, _) => ClearCurrent();
        Button openFolderButton = UtilityButton("OPEN FOLDER", 396, 32, 125);
        openFolderButton.Click += (_, _) => PasswordStore.OpenFolder(_settings.SaveFolder);
        Button refreshButton = UtilityButton("REFRESH", 531, 32, 100);
        refreshButton.Click += (_, _) => RefreshAllLists();

        actionsPanel.Controls.Add(generateButton);
        actionsPanel.Controls.Add(saveButton);
        actionsPanel.Controls.Add(clearButton);
        actionsPanel.Controls.Add(openFolderButton);
        actionsPanel.Controls.Add(refreshButton);

        tab.Controls.Add(savedPanel);
        tab.Controls.Add(configPanel);
        tab.Controls.Add(securityPanel);
        tab.Controls.Add(statusPanel);
        tab.Controls.Add(actionsPanel);

        return tab;
    }

    private TabPage BuildPasswordListTab()
    {
        TabPage tab = new("Password List");
        GroupBox listSection = Section("Saved Password List", 14, 14, 930, 420);

        _passwordGrid = new DataGridView
        {
            Left = 16,
            Top = 28,
            Width = 895,
            Height = 365,
            ReadOnly = true,
            AllowUserToAddRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        };

        listSection.Controls.Add(_passwordGrid);

        Button copyButton = UtilityButton("COPY", 14, 448, 100);
        copyButton.Click += (_, _) => CopySelectedPassword();
        Button editButton = UtilityButton("EDIT", 124, 448, 100);
        editButton.Click += (_, _) => EditSelectedEntry();
        Button deleteButton = UtilityButton("DELETE", 234, 448, 100);
        deleteButton.Click += (_, _) => DeleteSelectedEntry();
        Button refreshButton = UtilityButton("REFRESH", 344, 448, 100);
        refreshButton.Click += (_, _) => RefreshAllLists();

        Label note = new()
        {
            Text = "When PIN is enabled, .spgs files require the PIN to decrypt.",
            Left = 470,
            Top = 452,
            Width = 450,
            Height = 24
        };

        tab.Controls.Add(listSection);
        tab.Controls.Add(copyButton);
        tab.Controls.Add(editButton);
        tab.Controls.Add(deleteButton);
        tab.Controls.Add(refreshButton);
        tab.Controls.Add(note);

        return tab;
    }

    private TabPage BuildSavedFilesTab()
    {
        TabPage tab = new("Saved Files");
        GroupBox folderSection = Section("Save Location", 14, 14, 930, 105);
        Label folderLabel = FieldLabel("Folder", 16, 42, 90);
        _saveFolderBox = new TextBox { Left = 110, Top = 40, Width = 625, ReadOnly = true };

        Button chooseButton = UtilityButton("SELECT", 750, 38, 80);
        chooseButton.Click += (_, _) => ChooseSaveFolder();
        Button openButton = UtilityButton("OPEN", 840, 38, 70);
        openButton.Click += (_, _) => PasswordStore.OpenFolder(_settings.SaveFolder);

        folderSection.Controls.Add(folderLabel);
        folderSection.Controls.Add(_saveFolderBox);
        folderSection.Controls.Add(chooseButton);
        folderSection.Controls.Add(openButton);

        GroupBox filesSection = Section("Encrypted Files", 14, 135, 930, 320);
        _fileList = new ListBox { Left = 16, Top = 30, Width = 895, Height = 265 };
        filesSection.Controls.Add(_fileList);

        Button refreshButton = UtilityButton("REFRESH", 14, 470, 100);
        refreshButton.Click += (_, _) => RefreshAllLists();

        tab.Controls.Add(folderSection);
        tab.Controls.Add(filesSection);
        tab.Controls.Add(refreshButton);
        return tab;
    }

    private TabPage BuildOptionsTab()
    {
        TabPage tab = new("Options");
        GroupBox accessibility = Section("Accessibility", 14, 14, 930, 120);
        _ttsCheck = new CheckBox { Text = "Enable text-to-speech status messages", Left = 18, Top = 38, Width = 320 };
        _ttsCheck.CheckedChanged += (_, _) =>
        {
            _settings.TextToSpeechEnabled = _ttsCheck.Checked;
            SettingsService.Save(_settings);
        };

        Button testSpeechButton = UtilityButton("TEST", 350, 34, 80);
        testSpeechButton.Click += (_, _) => SpeechService.SpeakIfEnabled(_settings, "SecurePassGenSaver text to speech is enabled.");

        accessibility.Controls.Add(_ttsCheck);
        accessibility.Controls.Add(testSpeechButton);

        GroupBox dataSection = Section("Data Management", 14, 155, 930, 185);
        Button deleteDataButton = UtilityButton("DELETE ALL SAVED FILES", 18, 38, 210);
        deleteDataButton.Click += (_, _) => DeleteAllSavedData();
        Button resetSettingsButton = UtilityButton("RESET SETTINGS", 18, 82, 210);
        resetSettingsButton.Click += (_, _) => ResetSettings();

        Label deleteNote = new()
        {
            Text = "Deleting saved files removes both encrypted .spgs files and legacy .md files in the selected save folder.",
            Left = 260,
            Top = 42,
            Width = 620,
            Height = 70
        };

        dataSection.Controls.Add(deleteDataButton);
        dataSection.Controls.Add(resetSettingsButton);
        dataSection.Controls.Add(deleteNote);

        tab.Controls.Add(accessibility);
        tab.Controls.Add(dataSection);
        return tab;
    }

    private TabPage BuildSettingsTab()
    {
        TabPage tab = new("Settings");
        GroupBox appearance = Section("Appearance", 14, 14, 930, 110);
        Label themeLabel = FieldLabel("Theme", 18, 44, 90);

        _themeCombo = new ComboBox { Left = 120, Top = 42, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        _themeCombo.Items.AddRange(new object[] { "Dark", "Light", "System" });
        _themeCombo.SelectedIndexChanged += (_, _) =>
        {
            _settings.Theme = _themeCombo.SelectedItem?.ToString() ?? "Dark";
            SettingsService.Save(_settings);
            ApplyCurrentTheme();
        };

        appearance.Controls.Add(themeLabel);
        appearance.Controls.Add(_themeCombo);

        GroupBox pinSection = Section("App PIN Lock", 14, 145, 930, 260);
        Label warning = new()
        {
            Text = "PIN enabled files require the PIN to decrypt. Deleting settings will not unlock them.",
            Left = 18,
            Top = 34,
            Width = 760,
            Height = 25
        };

        _pinEnabledCheck = new CheckBox { Text = "PIN is enabled", Left = 18, Top = 72, Width = 180 };
        Label pinLabel = FieldLabel("PIN", 18, 115, 90);
        _pinBox = new TextBox { Left = 120, Top = 113, Width = 140, MaxLength = 4, PasswordChar = '●' };
        Label confirmLabel = FieldLabel("Confirm PIN", 18, 155, 90);
        _pinConfirmBox = new TextBox { Left = 120, Top = 153, Width = 140, MaxLength = 4, PasswordChar = '●' };
        Label hintLabel = FieldLabel("Hint", 300, 115, 80);
        _pinHintBox = new TextBox { Left = 385, Top = 113, Width = 360 };

        Button savePinButton = UtilityButton("SAVE PIN", 120, 200, 110);
        savePinButton.Click += (_, _) => SavePinSettings();
        Button disablePinButton = UtilityButton("DISABLE PIN", 240, 200, 130);
        disablePinButton.Click += (_, _) => DisablePin();

        pinSection.Controls.Add(warning);
        pinSection.Controls.Add(_pinEnabledCheck);
        pinSection.Controls.Add(pinLabel);
        pinSection.Controls.Add(_pinBox);
        pinSection.Controls.Add(confirmLabel);
        pinSection.Controls.Add(_pinConfirmBox);
        pinSection.Controls.Add(hintLabel);
        pinSection.Controls.Add(_pinHintBox);
        pinSection.Controls.Add(savePinButton);
        pinSection.Controls.Add(disablePinButton);

        tab.Controls.Add(appearance);
        tab.Controls.Add(pinSection);
        return tab;
    }

    private TabPage BuildAboutTab()
    {
        TabPage tab = new("?");

        GroupBox info = Section("Information", 14, 14, 930, 485);

        Label titleLabel = new()
        {
            Text = "SecurePassGenSaver",
            Left = 18,
            Top = 28,
            Width = 400,
            Height = 28,
            Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
        };

        Label versionLabel = new()
        {
            Text = "Version 1.5.0 — Portable encrypted password generator",
            Left = 18,
            Top = 58,
            Width = 650,
            Height = 24
        };

        TextBox aboutBox = new()
        {
            Left = 18,
            Top = 95,
            Width = 895,
            Height = 335,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            WordWrap = true,
            Font = new Font(Font.FontFamily, 9, FontStyle.Regular)
        };

        aboutBox.Lines = new[]
        {
            "Overview",
            "SecurePassGenSaver is an open-source C# Windows password generator designed as a practical cybersecurity portfolio project.",
            "",
            "Security",
            "• Passwords are generated locally on your computer.",
            "• The app uses .NET RandomNumberGenerator.",
            "• PIN-enabled saved files use PIN-based AES-GCM encryption.",
            "• Encrypted save files use the .spgs format.",
            "• Deleting the settings file does not unlock PIN-encrypted files.",
            "",
            "Portable release",
            "• The portable EXE can be moved to another folder and launched by itself.",
            "• The setup installer still installs the app into Program Files.",
            "• Desktop and Start Menu shortcuts are supported.",
            "",
            "Important",
            "This is an educational and portfolio project. For critical accounts, use a trusted password manager."
        };

        Label footerLabel = new()
        {
            Text = "No internet connection is required. Passwords are not sent anywhere.",
            Left = 18,
            Top = 445,
            Width = 895,
            Height = 24,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font(Font.FontFamily, 8, FontStyle.Bold)
        };

        info.Controls.Add(titleLabel);
        info.Controls.Add(versionLabel);
        info.Controls.Add(aboutBox);
        info.Controls.Add(footerLabel);

        tab.Controls.Add(info);
        return tab;
    }

    private PasswordGeneratorOptions CurrentOptions()
    {
        return new PasswordGeneratorOptions
        {
            Length = _lengthSlider.Value,
            UseLowercase = _lowercaseCheck.Checked,
            UseUppercase = _uppercaseCheck.Checked,
            UseNumbers = _numbersCheck.Checked,
            UseSymbols = _symbolsCheck.Checked,
            AvoidAmbiguous = _ambiguousCheck.Checked
        };
    }

    private void GeneratePassword()
    {
        PasswordGeneratorOptions options = CurrentOptions();
        string password = PasswordGenerator.Generate(options);
        _passwordBox.Text = password;

        double entropy = PasswordGenerator.CalculateEntropy(options);
        string strength = PasswordGenerator.StrengthLabel(entropy);

        _statusLabel.Text = $"GENERATED - {strength}";
        _securitySummaryLabel.Text = strength;
        SpeechService.SpeakIfEnabled(_settings, "Password generated.");
    }

    private void SaveCurrentPassword()
    {
        if (string.IsNullOrWhiteSpace(_passwordBox.Text))
        {
            MessageBox.Show("Generate a password first.", "Missing Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        PasswordEntry entry = new()
        {
            SaveName = string.IsNullOrWhiteSpace(_saveNameBox.Text) ? "password" : _saveNameBox.Text.Trim(),
            Username = _usernameBox.Text.Trim(),
            Password = _passwordBox.Text,
            CreatedLocal = DateTime.Now
        };

        PasswordStore.SaveEntry(_settings.SaveFolder, entry);
        RefreshAllLists();
        _statusLabel.Text = "SAVED ENCRYPTED ENTRY";
        _securitySummaryLabel.Text = "ENCRYPTED";
        SpeechService.SpeakIfEnabled(_settings, "Password saved.");
    }

    private void ClearCurrent()
    {
        _saveNameBox.Clear();
        _usernameBox.Clear();
        _passwordBox.Clear();
        _statusLabel.Text = "READY";
        _securitySummaryLabel.Text = "READY";
    }

    private void CopyGeneratedPassword()
    {
        if (!string.IsNullOrWhiteSpace(_passwordBox.Text))
        {
            Clipboard.SetText(_passwordBox.Text);
            _statusLabel.Text = "COPIED";
        }
    }

    private PasswordEntry? SelectedEntry()
    {
        if (_passwordGrid.CurrentRow?.DataBoundItem is PasswordEntry gridEntry)
        {
            return gridEntry;
        }

        if (_savedEntryList.SelectedItem is PasswordEntry listEntry)
        {
            return listEntry;
        }

        MessageBox.Show("Select a saved password first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return null;
    }

    private void LoadSelectedSavedEntry()
    {
        if (_savedEntryList.SelectedItem is not PasswordEntry entry)
        {
            MessageBox.Show("Select a saved entry first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _saveNameBox.Text = entry.SaveName.Replace(" (Legacy Plain Text)", "").Trim();
        _usernameBox.Text = entry.Username;
        _passwordBox.Text = entry.Password;
        _statusLabel.Text = "LOADED";
    }

    private void CopySelectedPassword()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        Clipboard.SetText(entry.Password);
        _statusLabel.Text = "COPIED SAVED ENTRY";
        MessageBox.Show("Password copied to clipboard.", "Copied", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void EditSelectedEntry()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        using EditEntryForm form = new(entry);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            PasswordStore.SaveEntry(_settings.SaveFolder, form.Entry);
            RefreshAllLists();
        }
    }

    private void DeleteSelectedEntry()
    {
        PasswordEntry? entry = SelectedEntry();
        if (entry == null) return;

        DialogResult result = MessageBox.Show("Delete this saved password file?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        PasswordStore.DeleteEntry(entry);
        RefreshAllLists();
        _statusLabel.Text = "DELETED";
    }

    private void RefreshAllLists()
    {
        RefreshPasswordList();
        RefreshSavedEntryList();
        RefreshFileList();
    }

    private void RefreshSavedEntryList()
    {
        List<PasswordEntry> entries = PasswordStore.LoadEntries(_settings.SaveFolder);
        _savedEntryList.DataSource = null;
        _savedEntryList.DisplayMember = "SaveName";
        _savedEntryList.DataSource = entries;
    }

    private void RefreshPasswordList()
    {
        List<PasswordEntry> entries = PasswordStore.LoadEntries(_settings.SaveFolder);
        _passwordGrid.DataSource = null;
        _passwordGrid.DataSource = entries;

        if (_passwordGrid.Columns["Password"] != null) _passwordGrid.Columns["Password"].Visible = false;
        if (_passwordGrid.Columns["FilePath"] != null) _passwordGrid.Columns["FilePath"].Visible = false;
    }

    private void RefreshFileList()
    {
        Directory.CreateDirectory(_settings.SaveFolder);

        if (_saveFolderBox != null) _saveFolderBox.Text = _settings.SaveFolder;
        if (_fileList == null) return;

        _fileList.Items.Clear();

        foreach (string file in Directory.GetFiles(_settings.SaveFolder, "*.spgs").Concat(Directory.GetFiles(_settings.SaveFolder, "*.md")).OrderByDescending(File.GetCreationTime))
        {
            _fileList.Items.Add(Path.GetFileName(file));
        }
    }

    private void ChooseSaveFolder()
    {
        using FolderBrowserDialog dialog = new()
        {
            Description = "Choose a folder or flash drive to save encrypted password files"
        };

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            _settings.SaveFolder = dialog.SelectedPath;
            SettingsService.Save(_settings);
            RefreshAllLists();
        }
    }

    private void DeleteAllSavedData()
    {
        DialogResult result = MessageBox.Show("Delete ALL saved password files in the current save folder?", "Danger", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        PasswordStore.DeleteAll(_settings.SaveFolder);
        RefreshAllLists();
        MessageBox.Show("Saved password files deleted.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void ResetSettings()
    {
        DialogResult result = MessageBox.Show("Reset app settings and disable PIN?", "Confirm Reset", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (result != DialogResult.Yes) return;

        SettingsService.Reset();
        _settings = SettingsService.Load();
        LoadSettingsToControls();
        ApplyCurrentTheme();
        RefreshAllLists();
    }

    private void SavePinSettings()
    {
        string pin = _pinBox.Text.Trim();
        string confirm = _pinConfirmBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(pin) || string.IsNullOrWhiteSpace(confirm))
        {
            MessageBox.Show("Enter and confirm a 4-digit PIN first.", "Missing PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!PinManager.IsValidPinFormat(pin))
        {
            MessageBox.Show("PIN must be exactly 4 digits.", "Invalid PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (pin != confirm)
        {
            MessageBox.Show("PIN confirmation does not match.", "Invalid PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        PinManager.SetPin(_settings, pin, _pinHintBox.Text);
        SettingsService.Save(_settings);
        PinSession.Set(pin);

        try
        {
            PasswordStore.ReEncryptAllWithCurrentPin(_settings.SaveFolder);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"PIN was saved, but existing files could not be fully migrated: {ex.Message}", "Migration Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        _pinEnabledCheck.Checked = true;
        _pinBox.Clear();
        _pinConfirmBox.Clear();

        RefreshAllLists();

        MessageBox.Show("PIN enabled. Saved password files now require this PIN to decrypt.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void DisablePin()
    {
        DialogResult result = MessageBox.Show(
            "Disabling the PIN will remove PIN-based file protection and convert readable entries back to Windows account protection only. Continue?",
            "Disable PIN",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

        if (result != DialogResult.Yes)
        {
            return;
        }

        try
        {
            if (PinSession.HasPin)
            {
                PasswordStore.ReEncryptAllWithoutPin(_settings.SaveFolder);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Some files could not be converted before disabling the PIN: {ex.Message}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        PinManager.DisablePin(_settings);
        PinSession.Clear();
        SettingsService.Save(_settings);

        _pinEnabledCheck.Checked = false;
        _pinBox.Clear();
        _pinConfirmBox.Clear();
        _pinHintBox.Clear();

        RefreshAllLists();

        MessageBox.Show("PIN disabled.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void LoadSettingsToControls()
    {
        _ttsCheck.Checked = _settings.TextToSpeechEnabled;

        _themeCombo.SelectedItem = _settings.Theme;
        if (_themeCombo.SelectedItem == null) _themeCombo.SelectedItem = "Dark";

        _pinEnabledCheck.Checked = _settings.PinEnabled;
        _pinHintBox.Text = _settings.PinHint;
        if (_saveFolderBox != null) _saveFolderBox.Text = _settings.SaveFolder;
    }

    private void ApplyCurrentTheme()
    {
        bool dark = _settings.Theme != "Light";

        if (dark)
        {
            Theme.ApplyDark(this);
            _lengthBubble.BackColor = Color.FromArgb(55, 55, 55);
            _lengthBubble.ForeColor = Color.WhiteSmoke;
            _lengthBubble.BorderStyle = BorderStyle.FixedSingle;
        }
        else
        {
            Theme.ApplyLight(this);
            _lengthBubble.BackColor = Color.White;
            _lengthBubble.ForeColor = Color.FromArgb(25, 25, 25);
            _lengthBubble.BorderStyle = BorderStyle.FixedSingle;
        }

        _tabs.DarkMode = dark;
        _tabs.Invalidate();
        DwmHelper.ApplyWindowTheme(this, dark);
        UpdateLengthAndEntropy();
    }

    private void UpdateLengthAndEntropy()
    {
        if (_lengthBubble == null || _entropyLabel == null || _lengthSlider == null) return;

        _lengthBubble.Text = _lengthSlider.Value.ToString();
        MoveLengthBubble();

        PasswordGeneratorOptions options = CurrentOptions();
        double entropy = PasswordGenerator.CalculateEntropy(options);
        string strength = PasswordGenerator.StrengthLabel(entropy);

        _entropyLabel.Text = $"Length: {_lengthSlider.Value} characters | Entropy: {entropy:0.00} bits";
        _securitySummaryLabel.Text = strength;
    }

    private void MoveLengthBubble()
    {
        int min = _lengthSlider.Minimum;
        int max = _lengthSlider.Maximum;
        int value = _lengthSlider.Value;

        double percent = (value - min) / (double)(max - min);
        int usableWidth = _lengthSlider.Width - 32;
        int x = _lengthSlider.Left + 16 + (int)(usableWidth * percent) - (_lengthBubble.Width / 2);

        int minX = _lengthSlider.Left;
        int maxX = _lengthSlider.Right - _lengthBubble.Width;

        if (x < minX) x = minX;
        if (x > maxX) x = maxX;

        _lengthBubble.Left = x;
    }
}
