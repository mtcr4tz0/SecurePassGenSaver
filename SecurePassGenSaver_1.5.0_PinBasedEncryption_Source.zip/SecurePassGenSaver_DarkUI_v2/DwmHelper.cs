using System.Runtime.InteropServices;

namespace SecurePassGenSaver;

public static class DwmHelper
{
    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_BORDER_COLOR = 34;
    private const int DWMWA_CAPTION_COLOR = 35;
    private const int DWMWA_TEXT_COLOR = 36;

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(
        IntPtr hwnd,
        int dwAttribute,
        ref int pvAttribute,
        int cbAttribute);

    public static void ApplyWindowTheme(Form form, bool dark)
    {
        if (!OperatingSystem.IsWindowsVersionAtLeast(10))
        {
            return;
        }

        try
        {
            int darkValue = dark ? 1 : 0;
            DwmSetWindowAttribute(form.Handle, DWMWA_USE_IMMERSIVE_DARK_MODE, ref darkValue, sizeof(int));

            if (OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000))
            {
                int borderColor = dark ? ColorToBgrInt(Color.FromArgb(95, 95, 95)) : ColorToBgrInt(Color.FromArgb(185, 190, 200));
                int captionColor = dark ? ColorToBgrInt(Color.FromArgb(32, 32, 32)) : ColorToBgrInt(Color.FromArgb(245, 246, 248));
                int textColor = dark ? ColorToBgrInt(Color.WhiteSmoke) : ColorToBgrInt(Color.FromArgb(25, 25, 25));

                DwmSetWindowAttribute(form.Handle, DWMWA_BORDER_COLOR, ref borderColor, sizeof(int));
                DwmSetWindowAttribute(form.Handle, DWMWA_CAPTION_COLOR, ref captionColor, sizeof(int));
                DwmSetWindowAttribute(form.Handle, DWMWA_TEXT_COLOR, ref textColor, sizeof(int));
            }
        }
        catch
        {
            // DWM title bar styling is optional. Never crash the app if Windows rejects it.
        }
    }

    private static int ColorToBgrInt(Color color)
    {
        return color.R | (color.G << 8) | (color.B << 16);
    }
}
