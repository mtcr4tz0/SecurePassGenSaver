# SecurePassGenSaver 1.4.2 — PIN Save Fix

Version 1.4.2 fixes the App PIN settings behavior.

## Fixed

- Pressing **Save PIN** no longer disables the PIN when the checkbox is unchecked.
- The app now saves and enables the PIN automatically after a valid 4-digit PIN is entered.
- The **Disable PIN** button is now the intended way to disable the PIN.
- Added clearer validation messages for missing, invalid, or mismatched PIN values.

## Correct behavior

To enable a PIN:

1. Enter a 4-digit PIN.
2. Confirm the same PIN.
3. Optionally enter a hint.
4. Click **Save PIN**.

The checkbox will update to show that the PIN is enabled.

To disable the PIN:

1. Click **Disable PIN**.
