After you run BUILD_SETUP.bat, upload this file to GitHub Releases:

InstallerOutput\SecurePassGenSaver-1.3.0-Setup.exe

This is the clean installer users should download.
