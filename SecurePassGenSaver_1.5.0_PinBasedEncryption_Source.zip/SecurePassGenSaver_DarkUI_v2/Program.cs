namespace SecurePassGenSaver;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        AppUserModelId.Set();

        AppPaths.EnsureBaseFolders();
        AppSettings settings = SettingsService.Load();

        if (settings.PinEnabled)
        {
            using LockForm lockForm = new(settings);
            if (lockForm.ShowDialog() != DialogResult.OK)
            {
                return;
            }
        }

        Application.Run(new MainForm());
    }
}
