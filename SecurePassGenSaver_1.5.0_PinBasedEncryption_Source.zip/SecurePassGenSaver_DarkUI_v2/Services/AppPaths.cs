namespace SecurePassGenSaver;

public static class AppPaths
{
    public static string AppFolder =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SecurePassGenSaver");

    public static string DefaultSaveFolder =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SecurePassGenSaver");

    public static string SettingsFile =>
        Path.Combine(AppFolder, "settings.json");

    public static void EnsureBaseFolders()
    {
        Directory.CreateDirectory(AppFolder);
        Directory.CreateDirectory(DefaultSaveFolder);
    }
}
