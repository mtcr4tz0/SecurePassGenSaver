using System.Security.Cryptography;

namespace SecurePassGenSaver;

public static class PasswordGenerator
{
    private const string Lowercase = "abcdefghijklmnopqrstuvwxyz";
    private const string Uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private const string Numbers = "0123456789";
    private const string Symbols = "!@#$%^&*()-_=+[]{};:,.<>?";
    private const string Ambiguous = "Il1O0";

    public static string Generate(PasswordGeneratorOptions options)
    {
        List<string> selectedSets = new();

        if (options.UseLowercase) selectedSets.Add(Clean(Lowercase, options.AvoidAmbiguous));
        if (options.UseUppercase) selectedSets.Add(Clean(Uppercase, options.AvoidAmbiguous));
        if (options.UseNumbers) selectedSets.Add(Clean(Numbers, options.AvoidAmbiguous));
        if (options.UseSymbols) selectedSets.Add(Symbols);

        selectedSets = selectedSets.Where(set => !string.IsNullOrWhiteSpace(set)).ToList();

        if (selectedSets.Count == 0)
        {
            selectedSets.Add(Clean(Lowercase, options.AvoidAmbiguous));
        }

        string allCharacters = string.Concat(selectedSets);
        List<char> chars = new();

        foreach (string set in selectedSets)
        {
            if (chars.Count < options.Length)
            {
                chars.Add(RandomChar(set));
            }
        }

        while (chars.Count < options.Length)
        {
            chars.Add(RandomChar(allCharacters));
        }

        Shuffle(chars);
        return new string(chars.ToArray());
    }

    public static double CalculateEntropy(PasswordGeneratorOptions options)
    {
        int poolSize = 0;

        if (options.UseLowercase) poolSize += Clean(Lowercase, options.AvoidAmbiguous).Length;
        if (options.UseUppercase) poolSize += Clean(Uppercase, options.AvoidAmbiguous).Length;
        if (options.UseNumbers) poolSize += Clean(Numbers, options.AvoidAmbiguous).Length;
        if (options.UseSymbols) poolSize += Symbols.Length;

        if (poolSize <= 0)
        {
            poolSize = Clean(Lowercase, options.AvoidAmbiguous).Length;
        }

        return options.Length * Math.Log2(poolSize);
    }

    public static string StrengthLabel(double entropy)
    {
        if (entropy >= 100) return "VERY STRONG";
        if (entropy >= 80) return "STRONG";
        if (entropy >= 60) return "GOOD";
        if (entropy >= 40) return "WEAK";
        return "VERY WEAK";
    }

    private static string Clean(string characters, bool avoidAmbiguous)
    {
        if (!avoidAmbiguous)
        {
            return characters;
        }

        return new string(characters.Where(ch => !Ambiguous.Contains(ch)).ToArray());
    }

    private static char RandomChar(string characters)
    {
        int index = RandomNumberGenerator.GetInt32(characters.Length);
        return characters[index];
    }

    private static void Shuffle(List<char> chars)
    {
        for (int i = chars.Count - 1; i > 0; i--)
        {
            int j = RandomNumberGenerator.GetInt32(i + 1);
            (chars[i], chars[j]) = (chars[j], chars[i]);
        }
    }
}
