using System.Security.Cryptography;

namespace SecurePassGenSaver;

public static class PinManager
{
    private const int SaltSize = 16;
    private const int HashSize = 32;
    private const int Iterations = 100_000;

    public static bool IsValidPinFormat(string pin)
    {
        return pin.Length == 4 && pin.All(char.IsDigit);
    }

    public static void SetPin(AppSettings settings, string pin, string hint)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = HashPin(pin, salt);

        settings.PinEnabled = true;
        settings.PinSaltBase64 = Convert.ToBase64String(salt);
        settings.PinHashBase64 = Convert.ToBase64String(hash);
        settings.PinHint = hint.Trim();
    }

    public static void DisablePin(AppSettings settings)
    {
        settings.PinEnabled = false;
        settings.PinSaltBase64 = "";
        settings.PinHashBase64 = "";
        settings.PinHint = "";
    }

    public static bool VerifyPin(AppSettings settings, string pin)
    {
        if (!settings.PinEnabled)
        {
            return true;
        }

        if (string.IsNullOrWhiteSpace(settings.PinSaltBase64) || string.IsNullOrWhiteSpace(settings.PinHashBase64))
        {
            return false;
        }

        byte[] salt = Convert.FromBase64String(settings.PinSaltBase64);
        byte[] expected = Convert.FromBase64String(settings.PinHashBase64);
        byte[] actual = HashPin(pin, salt);

        return CryptographicOperations.FixedTimeEquals(expected, actual);
    }

    private static byte[] HashPin(string pin, byte[] salt)
    {
        using Rfc2898DeriveBytes pbkdf2 = new(pin, salt, Iterations, HashAlgorithmName.SHA256);
        return pbkdf2.GetBytes(HashSize);
    }
}
