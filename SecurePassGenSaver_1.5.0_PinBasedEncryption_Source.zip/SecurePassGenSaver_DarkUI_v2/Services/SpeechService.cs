using System.Runtime.InteropServices;

namespace SecurePassGenSaver;

public static class SpeechService
{
    public static void SpeakIfEnabled(AppSettings settings, string text)
    {
        if (!settings.TextToSpeechEnabled)
        {
            return;
        }

        try
        {
            Type? voiceType = Type.GetTypeFromProgID("SAPI.SpVoice");
            if (voiceType == null) return;

            object? voice = Activator.CreateInstance(voiceType);
            if (voice == null) return;

            voiceType.InvokeMember("Speak", System.Reflection.BindingFlags.InvokeMethod, null, voice, new object[] { text });

            if (Marshal.IsComObject(voice))
            {
                Marshal.FinalReleaseComObject(voice);
            }
        }
        catch
        {
            // Optional feature. Do not crash if speech fails.
        }
    }
}
