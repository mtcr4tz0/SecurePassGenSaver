using System.Runtime.InteropServices;
using System.Text;

namespace SecurePassGenSaver;

public static class WindowsDataProtection
{
    private const int CRYPTPROTECT_UI_FORBIDDEN = 0x1;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct DATA_BLOB
    {
        public int cbData;
        public IntPtr pbData;
    }

    [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool CryptProtectData(
        ref DATA_BLOB pDataIn,
        string? szDataDescr,
        IntPtr pOptionalEntropy,
        IntPtr pvReserved,
        IntPtr pPromptStruct,
        int dwFlags,
        ref DATA_BLOB pDataOut);

    [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool CryptUnprotectData(
        ref DATA_BLOB pDataIn,
        IntPtr ppszDataDescr,
        IntPtr pOptionalEntropy,
        IntPtr pvReserved,
        IntPtr pPromptStruct,
        int dwFlags,
        ref DATA_BLOB pDataOut);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr LocalFree(IntPtr hMem);

    public static string ProtectToBase64(string plainText)
    {
        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
        byte[] encryptedBytes = Protect(plainBytes);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string UnprotectFromBase64(string encryptedBase64)
    {
        byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
        byte[] plainBytes = Unprotect(encryptedBytes);
        return Encoding.UTF8.GetString(plainBytes);
    }

    private static byte[] Protect(byte[] plainBytes)
    {
        DATA_BLOB input = CreateBlob(plainBytes);
        DATA_BLOB output = new();

        try
        {
            bool success = CryptProtectData(
                ref input,
                "SecurePassGenSaver",
                IntPtr.Zero,
                IntPtr.Zero,
                IntPtr.Zero,
                CRYPTPROTECT_UI_FORBIDDEN,
                ref output);

            if (!success)
            {
                throw new InvalidOperationException("Windows DPAPI encryption failed.");
            }

            return BlobToByteArray(output);
        }
        finally
        {
            if (input.pbData != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(input.pbData);
            }

            if (output.pbData != IntPtr.Zero)
            {
                LocalFree(output.pbData);
            }
        }
    }

    private static byte[] Unprotect(byte[] encryptedBytes)
    {
        DATA_BLOB input = CreateBlob(encryptedBytes);
        DATA_BLOB output = new();

        try
        {
            bool success = CryptUnprotectData(
                ref input,
                IntPtr.Zero,
                IntPtr.Zero,
                IntPtr.Zero,
                IntPtr.Zero,
                CRYPTPROTECT_UI_FORBIDDEN,
                ref output);

            if (!success)
            {
                throw new InvalidOperationException("Windows DPAPI decryption failed. This file may belong to another Windows user or another PC.");
            }

            return BlobToByteArray(output);
        }
        finally
        {
            if (input.pbData != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(input.pbData);
            }

            if (output.pbData != IntPtr.Zero)
            {
                LocalFree(output.pbData);
            }
        }
    }

    private static DATA_BLOB CreateBlob(byte[] data)
    {
        DATA_BLOB blob = new()
        {
            cbData = data.Length,
            pbData = Marshal.AllocHGlobal(data.Length)
        };

        Marshal.Copy(data, 0, blob.pbData, data.Length);
        return blob;
    }

    private static byte[] BlobToByteArray(DATA_BLOB blob)
    {
        if (blob.cbData <= 0 || blob.pbData == IntPtr.Zero)
        {
            return Array.Empty<byte>();
        }

        byte[] bytes = new byte[blob.cbData];
        Marshal.Copy(blob.pbData, bytes, 0, blob.cbData);
        return bytes;
    }
}
