using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SecurePassGenSaver;

public static class PinFileEncryption
{
    private const string Prefix = "SPGS2:";
    private const int SaltSize = 16;
    private const int NonceSize = 12;
    private const int KeySize = 32;
    private const int TagSize = 16;
    private const int Iterations = 250_000;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false
    };

    private sealed class EncryptedEnvelope
    {
        public string Format { get; set; } = "SPGS2-PIN-AESGCM";
        public string Kdf { get; set; } = "PBKDF2-SHA256";
        public int Iterations { get; set; } = PinFileEncryption.Iterations;
        public string SaltBase64 { get; set; } = "";
        public string NonceBase64 { get; set; } = "";
        public string TagBase64 { get; set; } = "";
        public string CiphertextBase64 { get; set; } = "";
    }

    public static bool IsPinEncrypted(string fileText)
    {
        return fileText.StartsWith(Prefix, StringComparison.Ordinal);
    }

    public static string Encrypt(string plainText, string pin)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(NonceSize);
        byte[] key = DeriveKey(pin, salt, Iterations);

        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
        byte[] cipherBytes = new byte[plainBytes.Length];
        byte[] tag = new byte[TagSize];

        using (AesGcm aes = new(key, TagSize))
        {
            aes.Encrypt(nonce, plainBytes, cipherBytes, tag);
        }

        CryptographicOperations.ZeroMemory(key);
        CryptographicOperations.ZeroMemory(plainBytes);

        EncryptedEnvelope envelope = new()
        {
            Iterations = Iterations,
            SaltBase64 = Convert.ToBase64String(salt),
            NonceBase64 = Convert.ToBase64String(nonce),
            TagBase64 = Convert.ToBase64String(tag),
            CiphertextBase64 = Convert.ToBase64String(cipherBytes)
        };

        string json = JsonSerializer.Serialize(envelope, JsonOptions);
        return Prefix + Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    public static string Decrypt(string fileText, string pin)
    {
        if (!IsPinEncrypted(fileText))
        {
            throw new InvalidOperationException("File is not PIN-encrypted.");
        }

        string base64 = fileText[Prefix.Length..].Trim();
        string json = Encoding.UTF8.GetString(Convert.FromBase64String(base64));

        EncryptedEnvelope? envelope = JsonSerializer.Deserialize<EncryptedEnvelope>(json, JsonOptions);
        if (envelope == null || envelope.Format != "SPGS2-PIN-AESGCM")
        {
            throw new InvalidOperationException("Unsupported encrypted file format.");
        }

        byte[] salt = Convert.FromBase64String(envelope.SaltBase64);
        byte[] nonce = Convert.FromBase64String(envelope.NonceBase64);
        byte[] tag = Convert.FromBase64String(envelope.TagBase64);
        byte[] cipherBytes = Convert.FromBase64String(envelope.CiphertextBase64);
        byte[] plainBytes = new byte[cipherBytes.Length];
        byte[] key = DeriveKey(pin, salt, envelope.Iterations);

        try
        {
            using (AesGcm aes = new(key, TagSize))
            {
                aes.Decrypt(nonce, cipherBytes, tag, plainBytes);
            }

            return Encoding.UTF8.GetString(plainBytes);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plainBytes);
        }
    }

    private static byte[] DeriveKey(string pin, byte[] salt, int iterations)
    {
        return Rfc2898DeriveBytes.Pbkdf2(
            password: pin,
            salt: salt,
            iterations: iterations,
            hashAlgorithm: HashAlgorithmName.SHA256,
            outputLength: KeySize);
    }
}
