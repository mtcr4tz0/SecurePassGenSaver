using System.Text.Json;

namespace SecurePassGenSaver;

public static class SettingsService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(AppPaths.SettingsFile))
            {
                AppSettings fresh = new();
                Save(fresh);
                return fresh;
            }

            string json = File.ReadAllText(AppPaths.SettingsFile);
            AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions);

            if (settings == null)
            {
                return new AppSettings();
            }

            if (string.IsNullOrWhiteSpace(settings.SaveFolder))
            {
                settings.SaveFolder = AppPaths.DefaultSaveFolder;
            }

            Directory.CreateDirectory(settings.SaveFolder);
            return settings;
        }
        catch
        {
            return new AppSettings();
        }
    }

    public static void Save(AppSettings settings)
    {
        Directory.CreateDirectory(AppPaths.AppFolder);
        Directory.CreateDirectory(settings.SaveFolder);
        string json = JsonSerializer.Serialize(settings, JsonOptions);
        File.WriteAllText(AppPaths.SettingsFile, json);
    }

    public static void Reset()
    {
        if (File.Exists(AppPaths.SettingsFile))
        {
            File.Delete(AppPaths.SettingsFile);
        }

        Save(new AppSettings());
    }
}
