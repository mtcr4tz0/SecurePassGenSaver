namespace SecurePassGenSaver;

public static class PinSession
{
    private static string? _pin;

    public static bool HasPin => !string.IsNullOrWhiteSpace(_pin);

    public static string CurrentPin
    {
        get
        {
            if (string.IsNullOrWhiteSpace(_pin))
            {
                throw new InvalidOperationException("PIN session is not unlocked.");
            }

            return _pin;
        }
    }

    public static void Set(string pin)
    {
        _pin = pin;
    }

    public static void Clear()
    {
        _pin = null;
    }
}
