namespace SecurePassGenSaver;

public class LockForm : Form
{
    private readonly AppSettings _settings;
    private readonly TextBox _pinBox = new();
    private readonly Label _messageLabel = new();

    public LockForm(AppSettings settings)
    {
        _settings = settings;

        Text = "SecurePassGenSaver Locked";
        AppIconHelper.Apply(this);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 380;
        Height = 240;

        Label title = new()
        {
            Text = "Enter your 4-digit PIN",
            AutoSize = true,
            Left = 30,
            Top = 25,
            Font = new Font(Font.FontFamily, 12, FontStyle.Bold)
        };

        _pinBox.Left = 30;
        _pinBox.Top = 65;
        _pinBox.Width = 300;
        _pinBox.MaxLength = 4;
        _pinBox.PasswordChar = '●';

        Button unlockButton = new()
        {
            Text = "Unlock",
            Left = 30,
            Top = 105,
            Width = 100
        };
        unlockButton.Click += (_, _) => TryUnlock();

        Button cancelButton = new()
        {
            Text = "Cancel",
            Left = 140,
            Top = 105,
            Width = 100
        };
        cancelButton.Click += (_, _) => DialogResult = DialogResult.Cancel;

        Label hintLabel = new()
        {
            Text = string.IsNullOrWhiteSpace(_settings.PinHint) ? "Hint: No hint set." : $"Hint: {_settings.PinHint}",
            AutoSize = false,
            Left = 30,
            Top = 145,
            Width = 310,
            Height = 25
        };

        _messageLabel.Left = 30;
        _messageLabel.Top = 170;
        _messageLabel.Width = 310;
        _messageLabel.Height = 25;

        Controls.Add(title);
        Controls.Add(_pinBox);
        Controls.Add(unlockButton);
        Controls.Add(cancelButton);
        Controls.Add(hintLabel);
        Controls.Add(_messageLabel);

        AcceptButton = unlockButton;
        Theme.ApplyDark(this);
        DwmHelper.ApplyWindowTheme(this, true);
    }

    private void TryUnlock()
    {
        if (PinManager.VerifyPin(_settings, _pinBox.Text))
        {
            PinSession.Set(_pinBox.Text);
            DialogResult = DialogResult.OK;
        }
        else
        {
            _messageLabel.Text = "Wrong PIN.";
            _pinBox.Clear();
            _pinBox.Focus();
        }
    }
}
