namespace SecurePassGenSaver;

public class EditEntryForm : Form
{
    private readonly TextBox _saveNameBox = new();
    private readonly TextBox _usernameBox = new();
    private readonly TextBox _passwordBox = new();

    public PasswordEntry Entry { get; }

    public EditEntryForm(PasswordEntry entry)
    {
        Entry = entry;

        Text = "Edit Saved Password";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 500;
        Height = 300;

        Label saveNameLabel = new() { Text = "Save file name:", Left = 25, Top = 25, Width = 120 };
        _saveNameBox.Left = 150;
        _saveNameBox.Top = 22;
        _saveNameBox.Width = 300;
        _saveNameBox.Text = entry.SaveName;

        Label usernameLabel = new() { Text = "Username:", Left = 25, Top = 70, Width = 120 };
        _usernameBox.Left = 150;
        _usernameBox.Top = 67;
        _usernameBox.Width = 300;
        _usernameBox.Text = entry.Username;

        Label passwordLabel = new() { Text = "Password:", Left = 25, Top = 115, Width = 120 };
        _passwordBox.Left = 150;
        _passwordBox.Top = 112;
        _passwordBox.Width = 300;
        _passwordBox.Text = entry.Password;

        Button saveButton = new() { Text = "Save", Left = 250, Top = 175, Width = 95 };
        saveButton.Click += (_, _) =>
        {
            Entry.SaveName = _saveNameBox.Text.Trim();
            Entry.Username = _usernameBox.Text.Trim();
            Entry.Password = _passwordBox.Text.Trim();
            DialogResult = DialogResult.OK;
        };

        Button cancelButton = new() { Text = "Cancel", Left = 355, Top = 175, Width = 95 };
        cancelButton.Click += (_, _) => DialogResult = DialogResult.Cancel;

        Controls.Add(saveNameLabel);
        Controls.Add(_saveNameBox);
        Controls.Add(usernameLabel);
        Controls.Add(_usernameBox);
        Controls.Add(passwordLabel);
        Controls.Add(_passwordBox);
        Controls.Add(saveButton);
        Controls.Add(cancelButton);

        Theme.ApplyDark(this);
    }
}
