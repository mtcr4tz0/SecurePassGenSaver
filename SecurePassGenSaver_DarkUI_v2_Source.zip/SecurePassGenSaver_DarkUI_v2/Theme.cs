namespace SecurePassGenSaver;

public static class Theme
{
    public static readonly Color DarkBack = Color.FromArgb(32, 32, 32);
    public static readonly Color PanelBack = Color.FromArgb(46, 46, 46);
    public static readonly Color ControlBack = Color.FromArgb(55, 55, 55);
    public static readonly Color Border = Color.FromArgb(95, 95, 95);
    public static readonly Color Text = Color.WhiteSmoke;

    public static void ApplyDark(Control root)
    {
        root.BackColor = DarkBack;
        root.ForeColor = Text;

        foreach (Control control in GetAllControls(root))
        {
            control.ForeColor = Text;

            if (control is TextBox textBox)
            {
                textBox.BackColor = ControlBack;
                textBox.ForeColor = Text;
                textBox.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (control is ComboBox comboBox)
            {
                comboBox.BackColor = ControlBack;
                comboBox.ForeColor = Text;
            }
            else if (control is Button button)
            {
                button.BackColor = ControlBack;
                button.ForeColor = Text;
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = Border;
                button.FlatAppearance.BorderSize = 1;
            }
            else if (control is ThemedTabControl themedTabs)
            {
                themedTabs.DarkMode = true;
                themedTabs.BackColor = DarkBack;
                themedTabs.ForeColor = Text;
                themedTabs.Invalidate();
            }
            else if (control is TabPage tabPage)
            {
                tabPage.BackColor = DarkBack;
            }
            else if (control is Panel panel)
            {
                panel.BackColor = PanelBack;
            }
            else if (control is GroupBox groupBox)
            {
                groupBox.BackColor = DarkBack;
                groupBox.ForeColor = Text;
            }
            else if (control is ListBox listBox)
            {
                listBox.BackColor = ControlBack;
                listBox.ForeColor = Text;
            }
            else if (control is DataGridView grid)
            {
                grid.BackgroundColor = ControlBack;
                grid.GridColor = Border;
                grid.BorderStyle = BorderStyle.FixedSingle;
                grid.EnableHeadersVisualStyles = false;
                grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(42, 42, 42);
                grid.ColumnHeadersDefaultCellStyle.ForeColor = Text;
                grid.DefaultCellStyle.BackColor = ControlBack;
                grid.DefaultCellStyle.ForeColor = Text;
                grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(80, 80, 80);
                grid.DefaultCellStyle.SelectionForeColor = Text;
                grid.RowHeadersDefaultCellStyle.BackColor = ControlBack;
                grid.RowHeadersDefaultCellStyle.ForeColor = Text;
            }
            else if (control is TrackBar)
            {
                control.BackColor = DarkBack;
            }
        }
    }

    public static void ApplyLight(Control root)
    {
        root.BackColor = SystemColors.Control;
        root.ForeColor = SystemColors.ControlText;

        foreach (Control control in GetAllControls(root))
        {
            control.ForeColor = SystemColors.ControlText;

            if (control is TextBox textBox)
            {
                textBox.BackColor = Color.White;
                textBox.ForeColor = Color.Black;
                textBox.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (control is Button button)
            {
                button.BackColor = SystemColors.Control;
                button.ForeColor = SystemColors.ControlText;
                button.FlatStyle = FlatStyle.Standard;
            }
            else if (control is ThemedTabControl themedTabs)
            {
                themedTabs.DarkMode = false;
                themedTabs.BackColor = SystemColors.Control;
                themedTabs.ForeColor = SystemColors.ControlText;
                themedTabs.Invalidate();
            }
            else if (control is TabPage tabPage)
            {
                tabPage.BackColor = SystemColors.Control;
            }
            else if (control is Panel panel)
            {
                panel.BackColor = SystemColors.Control;
            }
            else if (control is TrackBar)
            {
                control.BackColor = SystemColors.Control;
            }
        }
    }

    private static IEnumerable<Control> GetAllControls(Control root)
    {
        foreach (Control control in root.Controls)
        {
            yield return control;

            foreach (Control child in GetAllControls(control))
            {
                yield return child;
            }
        }
    }
}
