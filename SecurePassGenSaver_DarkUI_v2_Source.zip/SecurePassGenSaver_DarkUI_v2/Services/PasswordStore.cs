using System.Diagnostics;
using System.Text.RegularExpressions;

namespace SecurePassGenSaver;

public static class PasswordStore
{
    public static List<PasswordEntry> LoadEntries(string folder)
    {
        Directory.CreateDirectory(folder);

        List<PasswordEntry> entries = new();

        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            try
            {
                string text = File.ReadAllText(file);

                PasswordEntry entry = new()
                {
                    SaveName = MatchValue(text, @"\*\*Save Name:\*\*\s*(.+)"),
                    Username = MatchValue(text, @"\*\*Username:\*\*\s*(.+)"),
                    Password = MatchValue(text, @"\*\*Password:\*\*\s*`([^`]*)`"),
                    FilePath = file
                };

                string created = MatchValue(text, @"\*\*Created:\*\*\s*(.+)");
                if (DateTime.TryParse(created, out DateTime parsed))
                {
                    entry.CreatedLocal = parsed;
                }
                else
                {
                    entry.CreatedLocal = File.GetCreationTime(file);
                }

                if (!string.IsNullOrWhiteSpace(entry.Password))
                {
                    entries.Add(entry);
                }
            }
            catch
            {
                // Ignore unreadable files instead of crashing the app.
            }
        }

        return entries.OrderByDescending(entry => entry.CreatedLocal).ToList();
    }

    public static PasswordEntry SaveEntry(string folder, PasswordEntry entry)
    {
        Directory.CreateDirectory(folder);

        if (entry.CreatedLocal == default)
        {
            entry.CreatedLocal = DateTime.Now;
        }

        string safeName = MakeSafeFileName(entry.SaveName);
        if (string.IsNullOrWhiteSpace(safeName))
        {
            safeName = "password";
        }

        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string path = string.IsNullOrWhiteSpace(entry.FilePath)
            ? Path.Combine(folder, $"{safeName}_{timestamp}.md")
            : entry.FilePath;

        string content =
$@"# SecurePassGenSaver Password Entry

**Save Name:** {entry.SaveName}
**Username:** {entry.Username}
**Created:** {entry.CreatedLocal}

**Password:** `{entry.Password}`

## Security Note

This file stores the password in plain text because the user chose to save it as a readable Markdown file.
Keep this file only in a trusted folder or external drive.

Generated locally by SecurePassGenSaver.
";

        File.WriteAllText(path, content);
        entry.FilePath = path;
        return entry;
    }

    public static void DeleteEntry(PasswordEntry entry)
    {
        if (!string.IsNullOrWhiteSpace(entry.FilePath) && File.Exists(entry.FilePath))
        {
            File.Delete(entry.FilePath);
        }
    }

    public static void DeleteAll(string folder)
    {
        Directory.CreateDirectory(folder);

        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            File.Delete(file);
        }
    }

    public static void OpenFolder(string folder)
    {
        Directory.CreateDirectory(folder);

        ProcessStartInfo psi = new()
        {
            FileName = folder,
            UseShellExecute = true
        };

        Process.Start(psi);
    }

    private static string MatchValue(string text, string pattern)
    {
        Match match = Regex.Match(text, pattern);
        return match.Success ? match.Groups[1].Value.Trim() : "";
    }

    private static string MakeSafeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars())
        {
            name = name.Replace(c, '_');
        }

        return name.Trim();
    }
}
