namespace SecurePassGenSaver;

public class ThemedTabControl : TabControl
{
    public bool DarkMode { get; set; } = true;

    public ThemedTabControl()
    {
        DrawMode = TabDrawMode.OwnerDrawFixed;
        SizeMode = TabSizeMode.Fixed;
        ItemSize = new Size(120, 28);
        Padding = new Point(10, 4);
    }

    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        Graphics g = e.Graphics;
        Rectangle tabRect = GetTabRect(e.Index);
        bool selected = SelectedIndex == e.Index;

        Color back = DarkMode
            ? selected ? Color.FromArgb(46, 46, 46) : Color.FromArgb(34, 34, 34)
            : selected ? Color.White : Color.FromArgb(235, 235, 235);

        Color border = DarkMode ? Color.FromArgb(95, 95, 95) : Color.FromArgb(160, 160, 160);
        Color text = DarkMode ? Color.WhiteSmoke : Color.Black;

        using SolidBrush backBrush = new(back);
        using Pen borderPen = new(border);
        using SolidBrush textBrush = new(text);

        g.FillRectangle(backBrush, tabRect);
        g.DrawRectangle(borderPen, tabRect.X, tabRect.Y, tabRect.Width - 1, tabRect.Height - 1);

        string title = TabPages[e.Index].Text;
        StringFormat format = new()
        {
            Alignment = StringAlignment.Center,
            LineAlignment = StringAlignment.Center
        };

        g.DrawString(title, Font, textBrush, tabRect, format);
    }

    protected override void WndProc(ref Message m)
    {
        base.WndProc(ref m);

        // Paint the unused tab-header strip so it does not stay default white.
        if (m.Msg == 0x0F)
        {
            using Graphics g = CreateGraphics();
            Color back = DarkMode ? Color.FromArgb(32, 32, 32) : SystemColors.Control;
            using SolidBrush brush = new(back);

            Rectangle strip = new(0, 0, Width, ItemSize.Height + 4);
            g.FillRectangle(brush, strip);

            for (int i = 0; i < TabPages.Count; i++)
            {
                Rectangle tabRect = GetTabRect(i);
                bool selected = SelectedIndex == i;

                Color tabBack = DarkMode
                    ? selected ? Color.FromArgb(46, 46, 46) : Color.FromArgb(34, 34, 34)
                    : selected ? Color.White : Color.FromArgb(235, 235, 235);

                Color border = DarkMode ? Color.FromArgb(95, 95, 95) : Color.FromArgb(160, 160, 160);
                Color text = DarkMode ? Color.WhiteSmoke : Color.Black;

                using SolidBrush tabBrush = new(tabBack);
                using Pen borderPen = new(border);
                using SolidBrush textBrush = new(text);

                g.FillRectangle(tabBrush, tabRect);
                g.DrawRectangle(borderPen, tabRect.X, tabRect.Y, tabRect.Width - 1, tabRect.Height - 1);

                StringFormat format = new()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };

                g.DrawString(TabPages[i].Text, Font, textBrush, tabRect, format);
            }
        }
    }
}
