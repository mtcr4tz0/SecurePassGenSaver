using System.Runtime.InteropServices;

namespace SecurePassGenSaver;

public static class AppUserModelId
{
    [DllImport("shell32.dll", SetLastError = true)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(
        [MarshalAs(UnmanagedType.LPWStr)] string appID);

    public static void Set()
    {
        try
        {
            SetCurrentProcessExplicitAppUserModelID("Munkhtuvshin.SecurePassGenSaver.1.4.1");
        }
        catch
        {
            // Optional Windows shell integration. Never crash if it fails.
        }
    }
}
