namespace SecurePassGenSaver;

public class LockForm : Form
{
    private readonly AppSettings _settings;
    private readonly TextBox _passwordBox = new();
    private readonly Label _messageLabel = new();

    public LockForm(AppSettings settings)
    {
        _settings = settings;

        Text = "SecurePassGenSaver Locked";
        AppIconHelper.Apply(this);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 430;
        Height = 250;

        Label title = new()
        {
            Text = "Enter your master password",
            AutoSize = true,
            Left = 30,
            Top = 25,
            Font = new Font(Font.FontFamily, 12, FontStyle.Bold)
        };

        _passwordBox.Left = 30;
        _passwordBox.Top = 65;
        _passwordBox.Width = 350;
        _passwordBox.MaxLength = 128;
        _passwordBox.UseSystemPasswordChar = true;

        Button unlockButton = new()
        {
            Text = "Unlock",
            Left = 30,
            Top = 105,
            Width = 100
        };
        unlockButton.Click += (_, _) => TryUnlock();

        Button cancelButton = new()
        {
            Text = "Cancel",
            Left = 140,
            Top = 105,
            Width = 100
        };
        cancelButton.Click += (_, _) => DialogResult = DialogResult.Cancel;

        Label hintLabel = new()
        {
            Text = string.IsNullOrWhiteSpace(_settings.MasterPasswordHint) ? "Hint: No hint set." : $"Hint: {_settings.MasterPasswordHint}",
            AutoSize = false,
            Left = 30,
            Top = 145,
            Width = 360,
            Height = 25
        };

        _messageLabel.Left = 30;
        _messageLabel.Top = 172;
        _messageLabel.Width = 360;
        _messageLabel.Height = 25;

        Controls.Add(title);
        Controls.Add(_passwordBox);
        Controls.Add(unlockButton);
        Controls.Add(cancelButton);
        Controls.Add(hintLabel);
        Controls.Add(_messageLabel);

        AcceptButton = unlockButton;
        Theme.ApplyDark(this);
        DwmHelper.ApplyWindowTheme(this, true);
    }

    private void TryUnlock()
    {
        if (MasterPasswordManager.VerifyMasterPassword(_settings, _passwordBox.Text))
        {
            MasterPasswordSession.Set(_passwordBox.Text);
            DialogResult = DialogResult.OK;
        }
        else
        {
            _messageLabel.Text = "Wrong master password.";
            _passwordBox.Clear();
            _passwordBox.Focus();
        }
    }
}
