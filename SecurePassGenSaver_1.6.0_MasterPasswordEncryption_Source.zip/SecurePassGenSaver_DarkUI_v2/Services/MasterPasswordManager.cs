using System.Security.Cryptography;

namespace SecurePassGenSaver;

public static class MasterPasswordManager
{
    private const int SaltSize = 16;
    private const int HashSize = 32;

    // Keep 100,000 here so existing v1.5.0 PIN hashes can still verify.
    // File encryption itself uses a stronger KDF setting inside MasterFileEncryption.
    private const int VerificationIterations = 100_000;

    public static bool IsValidMasterPasswordFormat(string password)
    {
        if (string.IsNullOrWhiteSpace(password)) return false;
        if (password.Length < 8 || password.Length > 128) return false;

        bool hasLetter = password.Any(char.IsLetter);
        bool hasNumberOrSymbol = password.Any(c => char.IsDigit(c) || char.IsPunctuation(c) || char.IsSymbol(c));

        return hasLetter && hasNumberOrSymbol;
    }

    public static string RulesText => "Master password must be 8-128 characters and include letters plus numbers or symbols.";

    public static void SetMasterPassword(AppSettings settings, string password, string hint)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = HashPassword(password, salt);

        settings.MasterPasswordEnabled = true;
        settings.MasterPasswordSaltBase64 = Convert.ToBase64String(salt);
        settings.MasterPasswordHashBase64 = Convert.ToBase64String(hash);
        settings.MasterPasswordHint = hint.Trim();
    }

    public static void DisableMasterPassword(AppSettings settings)
    {
        settings.MasterPasswordEnabled = false;
        settings.MasterPasswordSaltBase64 = "";
        settings.MasterPasswordHashBase64 = "";
        settings.MasterPasswordHint = "";
    }

    public static bool VerifyMasterPassword(AppSettings settings, string password)
    {
        if (!settings.MasterPasswordEnabled)
        {
            return true;
        }

        if (string.IsNullOrWhiteSpace(settings.MasterPasswordSaltBase64) || string.IsNullOrWhiteSpace(settings.MasterPasswordHashBase64))
        {
            return false;
        }

        byte[] salt = Convert.FromBase64String(settings.MasterPasswordSaltBase64);
        byte[] expected = Convert.FromBase64String(settings.MasterPasswordHashBase64);
        byte[] actual = HashPassword(password, salt);

        try
        {
            return CryptographicOperations.FixedTimeEquals(expected, actual);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(actual);
        }
    }

    private static byte[] HashPassword(string password, byte[] salt)
    {
        using Rfc2898DeriveBytes pbkdf2 = new(password, salt, VerificationIterations, HashAlgorithmName.SHA256);
        return pbkdf2.GetBytes(HashSize);
    }
}
