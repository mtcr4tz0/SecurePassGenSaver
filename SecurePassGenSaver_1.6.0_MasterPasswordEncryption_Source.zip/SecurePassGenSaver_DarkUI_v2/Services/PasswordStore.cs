using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace SecurePassGenSaver;

public static class PasswordStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public static List<PasswordEntry> LoadEntries(string folder)
    {
        string? password = MasterPasswordSession.HasPassword ? MasterPasswordSession.CurrentPassword : null;
        return LoadEntries(folder, password);
    }

    public static List<PasswordEntry> LoadEntries(string folder, string? masterPassword)
    {
        Directory.CreateDirectory(folder);

        List<PasswordEntry> entries = new();

        foreach (string file in Directory.GetFiles(folder, "*.spgs"))
        {
            try
            {
                string fileText = File.ReadAllText(file);
                string json;

                if (MasterFileEncryption.IsMasterEncrypted(fileText))
                {
                    if (string.IsNullOrEmpty(masterPassword))
                    {
                        continue;
                    }

                    json = MasterFileEncryption.Decrypt(fileText, masterPassword);
                }
                else
                {
                    // Legacy 1.3/1.4 DPAPI-only encrypted file.
                    json = WindowsDataProtection.UnprotectFromBase64(fileText);
                }

                PasswordEntry? entry = JsonSerializer.Deserialize<PasswordEntry>(json, JsonOptions);

                if (entry != null && !string.IsNullOrWhiteSpace(entry.Password))
                {
                    entry.FilePath = file;
                    entries.Add(entry);
                }
            }
            catch
            {
                // Wrong master password, different Windows user, corrupted file, or unsupported file.
                // Do not crash the app. Just skip unreadable entries.
            }
        }

        // Legacy support: old Markdown files from early versions can still be listed.
        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            try
            {
                string text = File.ReadAllText(file);

                PasswordEntry entry = new()
                {
                    SaveName = MatchValue(text, @"\*\*Save Name:\*\*\s*(.+)") + " (Legacy Plain Text)",
                    Username = MatchValue(text, @"\*\*Username:\*\*\s*(.+)"),
                    Password = MatchValue(text, @"\*\*Password:\*\*\s*`([^`]*)`"),
                    FilePath = file
                };

                string created = MatchValue(text, @"\*\*Created:\*\*\s*(.+)");
                if (DateTime.TryParse(created, out DateTime parsed))
                {
                    entry.CreatedLocal = parsed;
                }
                else
                {
                    entry.CreatedLocal = File.GetCreationTime(file);
                }

                if (!string.IsNullOrWhiteSpace(entry.Password))
                {
                    entries.Add(entry);
                }
            }
            catch
            {
                // Ignore broken legacy files.
            }
        }

        return entries.OrderByDescending(entry => entry.CreatedLocal).ToList();
    }

    public static PasswordEntry SaveEntry(string folder, PasswordEntry entry)
    {
        Directory.CreateDirectory(folder);

        if (entry.CreatedLocal == default)
        {
            entry.CreatedLocal = DateTime.Now;
        }

        string safeName = MakeSafeFileName(entry.SaveName.Replace(" (Legacy Plain Text)", "").Trim());
        if (string.IsNullOrWhiteSpace(safeName))
        {
            safeName = "password";
        }

        bool isLegacyMarkdown = entry.FilePath.EndsWith(".md", StringComparison.OrdinalIgnoreCase);
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        string path = string.IsNullOrWhiteSpace(entry.FilePath) || isLegacyMarkdown
            ? Path.Combine(folder, $"{safeName}_{timestamp}.spgs")
            : entry.FilePath;

        PasswordEntry cleanEntry = new()
        {
            SaveName = entry.SaveName.Replace(" (Legacy Plain Text)", "").Trim(),
            Username = entry.Username,
            Password = entry.Password,
            CreatedLocal = entry.CreatedLocal,
            FilePath = ""
        };

        string json = JsonSerializer.Serialize(cleanEntry, JsonOptions);
        string protectedText = MasterPasswordSession.HasPassword
            ? MasterFileEncryption.Encrypt(json, MasterPasswordSession.CurrentPassword)
            : WindowsDataProtection.ProtectToBase64(json);

        File.WriteAllText(path, protectedText);

        entry.FilePath = path;
        entry.SaveName = cleanEntry.SaveName;
        return entry;
    }

    public static void ReEncryptAllWithNewMasterPassword(string folder, string? oldMasterPassword, string newMasterPassword)
    {
        List<PasswordEntry> entries = LoadEntries(folder, oldMasterPassword);
        MasterPasswordSession.Set(newMasterPassword);

        foreach (PasswordEntry entry in entries)
        {
            string oldPath = entry.FilePath;
            entry.FilePath = "";

            if (!string.IsNullOrWhiteSpace(oldPath) && File.Exists(oldPath))
            {
                File.Delete(oldPath);
            }

            SaveEntry(folder, entry);
        }
    }

    public static void ReEncryptAllWithoutMasterPassword(string folder)
    {
        List<PasswordEntry> entries = LoadEntries(folder);
        MasterPasswordSession.Clear();

        foreach (PasswordEntry entry in entries)
        {
            string oldPath = entry.FilePath;
            entry.FilePath = "";

            if (!string.IsNullOrWhiteSpace(oldPath) && File.Exists(oldPath))
            {
                File.Delete(oldPath);
            }

            SaveEntry(folder, entry);
        }
    }

    public static int CountMasterEncryptedFiles(string folder)
    {
        Directory.CreateDirectory(folder);

        int count = 0;

        foreach (string file in Directory.GetFiles(folder, "*.spgs"))
        {
            try
            {
                if (MasterFileEncryption.IsMasterEncrypted(File.ReadAllText(file)))
                {
                    count++;
                }
            }
            catch
            {
                // Ignore unreadable files.
            }
        }

        return count;
    }

    public static void DeleteEntry(PasswordEntry entry)
    {
        if (!string.IsNullOrWhiteSpace(entry.FilePath) && File.Exists(entry.FilePath))
        {
            File.Delete(entry.FilePath);
        }
    }

    public static void DeleteAll(string folder)
    {
        Directory.CreateDirectory(folder);

        foreach (string file in Directory.GetFiles(folder, "*.spgs"))
        {
            File.Delete(file);
        }

        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            File.Delete(file);
        }
    }

    public static void OpenFolder(string folder)
    {
        Directory.CreateDirectory(folder);

        ProcessStartInfo psi = new()
        {
            FileName = folder,
            UseShellExecute = true
        };

        Process.Start(psi);
    }

    private static string MatchValue(string text, string pattern)
    {
        Match match = Regex.Match(text, pattern);
        return match.Success ? match.Groups[1].Value.Trim() : "";
    }

    private static string MakeSafeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars())
        {
            name = name.Replace(c, '_');
        }

        return name.Trim();
    }
}
