namespace SecurePassGenSaver;

public static class MasterPasswordSession
{
    private static string? _password;

    public static bool HasPassword => !string.IsNullOrEmpty(_password);

    public static string CurrentPassword
    {
        get
        {
            if (string.IsNullOrEmpty(_password))
            {
                throw new InvalidOperationException("Master password session is not unlocked.");
            }

            return _password;
        }
    }

    public static void Set(string password)
    {
        _password = password;
    }

    public static void Clear()
    {
        _password = null;
    }
}
