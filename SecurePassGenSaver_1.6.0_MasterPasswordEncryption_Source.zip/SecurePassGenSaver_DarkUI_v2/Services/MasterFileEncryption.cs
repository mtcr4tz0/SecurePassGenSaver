using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SecurePassGenSaver;

public static class MasterFileEncryption
{
    private const string PrefixV2 = "SPGS2:"; // v1.5.0 PIN-based files
    private const string PrefixV3 = "SPGS3:"; // v1.6.0 master-password files
    private const int SaltSize = 16;
    private const int NonceSize = 12;
    private const int KeySize = 32;
    private const int TagSize = 16;
    private const int Iterations = 600_000;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false
    };

    private sealed class EncryptedEnvelope
    {
        public string Format { get; set; } = "SPGS3-MASTER-AESGCM";
        public string Kdf { get; set; } = "PBKDF2-SHA256";
        public int Iterations { get; set; } = MasterFileEncryption.Iterations;
        public string SaltBase64 { get; set; } = "";
        public string NonceBase64 { get; set; } = "";
        public string TagBase64 { get; set; } = "";
        public string CiphertextBase64 { get; set; } = "";
    }

    public static bool IsMasterEncrypted(string fileText)
    {
        string trimmed = fileText.Trim();
        return trimmed.StartsWith(PrefixV2, StringComparison.Ordinal) || trimmed.StartsWith(PrefixV3, StringComparison.Ordinal);
    }

    public static string Encrypt(string plainText, string masterPassword)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(NonceSize);
        byte[] key = DeriveKey(masterPassword, salt, Iterations);

        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
        byte[] cipherBytes = new byte[plainBytes.Length];
        byte[] tag = new byte[TagSize];

        try
        {
            using (AesGcm aes = new(key, TagSize))
            {
                aes.Encrypt(nonce, plainBytes, cipherBytes, tag);
            }

            EncryptedEnvelope envelope = new()
            {
                Format = "SPGS3-MASTER-AESGCM",
                Iterations = Iterations,
                SaltBase64 = Convert.ToBase64String(salt),
                NonceBase64 = Convert.ToBase64String(nonce),
                TagBase64 = Convert.ToBase64String(tag),
                CiphertextBase64 = Convert.ToBase64String(cipherBytes)
            };

            string json = JsonSerializer.Serialize(envelope, JsonOptions);
            return PrefixV3 + Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plainBytes);
        }
    }

    public static string Decrypt(string fileText, string masterPassword)
    {
        string trimmed = fileText.Trim();
        string base64;

        if (trimmed.StartsWith(PrefixV3, StringComparison.Ordinal))
        {
            base64 = trimmed[PrefixV3.Length..].Trim();
        }
        else if (trimmed.StartsWith(PrefixV2, StringComparison.Ordinal))
        {
            base64 = trimmed[PrefixV2.Length..].Trim();
        }
        else
        {
            throw new InvalidOperationException("File is not master-password encrypted.");
        }

        string json = Encoding.UTF8.GetString(Convert.FromBase64String(base64));

        EncryptedEnvelope? envelope = JsonSerializer.Deserialize<EncryptedEnvelope>(json, JsonOptions);
        if (envelope == null || (envelope.Format != "SPGS3-MASTER-AESGCM" && envelope.Format != "SPGS2-PIN-AESGCM"))
        {
            throw new InvalidOperationException("Unsupported encrypted file format.");
        }

        byte[] salt = Convert.FromBase64String(envelope.SaltBase64);
        byte[] nonce = Convert.FromBase64String(envelope.NonceBase64);
        byte[] tag = Convert.FromBase64String(envelope.TagBase64);
        byte[] cipherBytes = Convert.FromBase64String(envelope.CiphertextBase64);
        byte[] plainBytes = new byte[cipherBytes.Length];
        byte[] key = DeriveKey(masterPassword, salt, envelope.Iterations);

        try
        {
            using (AesGcm aes = new(key, TagSize))
            {
                aes.Decrypt(nonce, cipherBytes, tag, plainBytes);
            }

            return Encoding.UTF8.GetString(plainBytes);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plainBytes);
        }
    }

    private static byte[] DeriveKey(string masterPassword, byte[] salt, int iterations)
    {
        return Rfc2898DeriveBytes.Pbkdf2(
            password: masterPassword,
            salt: salt,
            iterations: iterations,
            hashAlgorithm: HashAlgorithmName.SHA256,
            outputLength: KeySize);
    }
}
