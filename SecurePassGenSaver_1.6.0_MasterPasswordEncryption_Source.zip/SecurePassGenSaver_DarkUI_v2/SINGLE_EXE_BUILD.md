# Single EXE / Installer Build

This version is configured so the published app is mostly one clean file:

```text
SecurePassGenSaver.exe
```

This avoids showing users a messy folder full of `.dll` files.

## Build Single EXE

Open PowerShell in the project folder and run:

```powershell
.\Scripts\build-single-exe.ps1
```

or:

```powershell
.\Scripts\build-publish.ps1
```

Both scripts now build a self-contained single-file Windows EXE.

The output will be here:

```text
Publish\SecurePassGenSaver.exe
```

## Build Setup Installer

After building the single EXE, open this file in Inno Setup:

```text
Installer\SecurePassGenSaver.iss
```

Press:

```text
Compile
```

The setup installer will be created here:

```text
InstallerOutput\SecurePassGenSaver-1.6.0-Setup.exe
```

## What Users Should Download

Normal users should download:

```text
SecurePassGenSaver-1.6.0-Setup.exe
```

They should not download the raw `Publish` folder.

The installer will put the app into:

```text
C:\Program Files\SecurePassGenSaver
```

and create shortcuts on:

```text
Desktop
Start Menu
Windows Search
```
