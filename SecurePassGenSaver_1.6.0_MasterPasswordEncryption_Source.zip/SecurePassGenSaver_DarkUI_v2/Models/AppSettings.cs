using System.Text.Json.Serialization;

namespace SecurePassGenSaver;

public class AppSettings
{
    public string SaveFolder { get; set; } = AppPaths.DefaultSaveFolder;
    public string Theme { get; set; } = "Dark";
    public bool TextToSpeechEnabled { get; set; } = false;

    // Stored with the old property names for compatibility with settings from v1.5.0 and older.
    public bool PinEnabled { get; set; } = false;
    public string PinSaltBase64 { get; set; } = "";
    public string PinHashBase64 { get; set; } = "";
    public string PinHint { get; set; } = "";

    [JsonIgnore]
    public bool MasterPasswordEnabled
    {
        get => PinEnabled;
        set => PinEnabled = value;
    }

    [JsonIgnore]
    public string MasterPasswordSaltBase64
    {
        get => PinSaltBase64;
        set => PinSaltBase64 = value;
    }

    [JsonIgnore]
    public string MasterPasswordHashBase64
    {
        get => PinHashBase64;
        set => PinHashBase64 = value;
    }

    [JsonIgnore]
    public string MasterPasswordHint
    {
        get => PinHint;
        set => PinHint = value;
    }
}
