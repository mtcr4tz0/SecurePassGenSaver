# SecurePassGenSaver 1.6.0 — Master Password Encryption Release

Version 1.6.0 replaces the weak 4-digit PIN design with a stronger master password system.

## What Changed

- Replaced the 4-digit PIN workflow with a master password workflow.
- Master passwords can be 8-128 characters.
- Master password must include letters plus numbers or symbols.
- Saved `.spgs` files now use the `SPGS3` master-password encrypted format.
- USB/flash-drive stored password files can be unlocked on another PC using the same master password.
- Existing `SPGS2` files from version 1.5.0 can still be read if the old PIN/password is entered.
- Setting a new master password migrates readable entries to the new `SPGS3` format.

## Encryption Details

When master password protection is enabled, saved files use:

- PBKDF2-SHA256
- 600,000 iterations
- AES-GCM encryption
- Random salt per file
- Random nonce per file

## Why This Version Matters

Version 1.5.0 fixed the settings-delete PIN bypass by making the PIN part of file encryption. Version 1.6.0 improves that idea by replacing the 4-digit PIN with a stronger master password.

This is better for USB portability because the files are not tied only to one Windows account. The same `.spgs` files can be unlocked on another PC if the correct master password is used.

## Important Warning

If you forget the master password, master-password encrypted saved passwords cannot be recovered.
