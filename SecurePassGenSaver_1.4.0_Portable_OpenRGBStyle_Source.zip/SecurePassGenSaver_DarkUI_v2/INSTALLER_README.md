# Installer Build Instructions

This project includes an Inno Setup installer script.

The installer will:

- Install SecurePassGenSaver into `C:\Program Files\SecurePassGenSaver`
- Use the custom key icon for the app
- Use the custom key icon for the installer
- Create a Desktop shortcut if selected during setup
- Create a Start Menu shortcut
- Make the app searchable from Windows Search
- Add an Uninstall entry in Windows settings
- Launch the app after installation if the user chooses

## Step 1: Build the app

Open PowerShell in the project folder and run:

```powershell
.\Scripts\build-single-exe.ps1
```

This creates:

```text
Publish\SecurePassGenSaver.exe
```

## Step 2: Install Inno Setup

Install Inno Setup.

## Step 3: Compile the installer

Open:

```text
Installer\SecurePassGenSaver.iss
```

Then press:

```text
Compile
```

The final setup file will be created here:

```text
InstallerOutput\SecurePassGenSaver-1.3.0-Setup.exe
```

## Windows Search and Pinning

Windows Search finds the app through the Start Menu shortcut created by the installer.

Users can pin the app manually:

- Search `SecurePassGenSaver`
- Right-click it
- Choose `Pin to taskbar` or `Pin to Start`
