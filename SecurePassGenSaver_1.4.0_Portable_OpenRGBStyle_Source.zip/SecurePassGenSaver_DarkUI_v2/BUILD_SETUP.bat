@echo off
setlocal EnableDelayedExpansion
title SecurePassGenSaver 1.4.0 Setup Builder
cd /d "%~dp0"

set "LOG=%~dp0build_error.log"

echo ==============================================
echo SecurePassGenSaver 1.4.0 Setup Builder
echo ==============================================
echo.
echo WHERE THE FILES GO:
echo Portable EXE: Publish\SecurePassGenSaver.exe
echo Final installer: InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe
echo.
echo Build log:
echo %LOG%
echo.

if exist "%LOG%" del "%LOG%"

echo [1/4] Checking .NET SDK...
dotnet --version >nul 2>>"%LOG%"
if errorlevel 1 (
    echo ERROR: .NET SDK is not installed or dotnet is not in PATH.
    echo Install .NET 8 SDK or newer, then run this again.
    echo ERROR: dotnet command not found.>>"%LOG%"
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('dotnet --version') do set DOTNET_VERSION=%%i
echo .NET detected: %DOTNET_VERSION%
echo .NET detected: %DOTNET_VERSION%>>"%LOG%"

echo.
echo [2/4] Cleaning old build folders...
if exist "Publish" rmdir /s /q "Publish"
if exist "InstallerOutput" rmdir /s /q "InstallerOutput"
mkdir "Publish" >nul 2>&1

echo.
echo [3/4] Building self-contained portable single-file EXE...
echo.
echo This build can be moved to another folder and launched by itself.
echo It is larger, but it avoids missing DLL/runtime problems.
echo.

dotnet restore "SecurePassGenSaver.csproj" >>"%LOG%" 2>&1
if errorlevel 1 (
    echo ERROR: dotnet restore failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

dotnet publish "SecurePassGenSaver.csproj" ^
    -c Release ^
    -r win-x64 ^
    --self-contained true ^
    /p:PublishSingleFile=true ^
    /p:IncludeNativeLibrariesForSelfExtract=true ^
    /p:EnableCompressionInSingleFile=true ^
    /p:PublishTrimmed=false ^
    /p:DebugType=None ^
    /p:DebugSymbols=false ^
    /p:PublishDir="%cd%\Publish\" >>"%LOG%" 2>&1

if errorlevel 1 (
    echo ERROR: dotnet publish failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

if not exist "Publish\SecurePassGenSaver.exe" (
    echo ERROR: Publish\SecurePassGenSaver.exe was not created.
    echo Publish output missing.>>"%LOG%"
    pause
    exit /b 1
)

echo Portable EXE ready:
echo %cd%\Publish\SecurePassGenSaver.exe
echo.

echo [4/4] Creating setup installer with Inno Setup...

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if "%ISCC%"=="" (
    echo.
    echo Inno Setup was not found.
    echo.
    echo The portable app EXE was built successfully:
    echo Publish\SecurePassGenSaver.exe
    echo.
    echo To create the setup installer, install Inno Setup and run this again.
    echo.
    echo Inno Setup not found.>>"%LOG%"
    pause
    exit /b 1
)

"%ISCC%" "Installer\SecurePassGenSaver.iss" >>"%LOG%" 2>&1
if errorlevel 1 (
    echo ERROR: Inno Setup failed.
    echo Open build_error.log for details.
    pause
    exit /b 1
)

if not exist "InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe" (
    echo ERROR: Setup file was not created.
    echo Missing InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe>>"%LOG%"
    pause
    exit /b 1
)

echo.
echo ==============================================
echo DONE
echo ==============================================
echo.
echo Portable EXE:
echo %cd%\Publish\SecurePassGenSaver.exe
echo.
echo Final installer:
echo %cd%\InstallerOutput\SecurePassGenSaver-1.4.0-Setup.exe
echo.
echo Upload the setup file to GitHub Releases.
echo.
explorer "InstallerOutput"
pause
