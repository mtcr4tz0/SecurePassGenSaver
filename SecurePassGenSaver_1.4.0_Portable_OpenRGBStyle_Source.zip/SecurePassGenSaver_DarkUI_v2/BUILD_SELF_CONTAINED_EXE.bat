@echo off
setlocal
title SecurePassGenSaver 1.3.0 Self-Contained Setup Builder
cd /d "%~dp0"

set "LOG=%~dp0build_selfcontained_error.log"

echo ==============================================
echo SecurePassGenSaver 1.3.0 Self-Contained Builder
echo ==============================================
echo.
echo This creates a bigger EXE that does not require users to install .NET.
echo.

if exist "%LOG%" del "%LOG%"
if exist "Publish" rmdir /s /q "Publish"

dotnet restore "SecurePassGenSaver.csproj" >>"%LOG%" 2>&1
if errorlevel 1 (
    echo ERROR: dotnet restore failed.
    echo Open build_selfcontained_error.log for details.
    pause
    exit /b 1
)

dotnet publish "SecurePassGenSaver.csproj" ^
    -c Release ^
    -r win-x64 ^
    --self-contained true ^
    /p:PublishSingleFile=true ^
    /p:IncludeNativeLibrariesForSelfExtract=true ^
    /p:EnableCompressionInSingleFile=true ^
    /p:PublishTrimmed=false ^
    /p:DebugType=None ^
    /p:DebugSymbols=false ^
    /p:PublishDir="Publish\" >>"%LOG%" 2>&1

if errorlevel 1 (
    echo ERROR: Self-contained publish failed.
    echo Open build_selfcontained_error.log for details.
    pause
    exit /b 1
)

echo DONE:
echo Publish\SecurePassGenSaver.exe
pause
