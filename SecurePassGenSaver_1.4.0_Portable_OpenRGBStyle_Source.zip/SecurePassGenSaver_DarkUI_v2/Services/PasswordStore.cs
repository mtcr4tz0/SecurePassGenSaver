using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace SecurePassGenSaver;

public static class PasswordStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public static List<PasswordEntry> LoadEntries(string folder)
    {
        Directory.CreateDirectory(folder);

        List<PasswordEntry> entries = new();

        foreach (string file in Directory.GetFiles(folder, "*.spgs"))
        {
            try
            {
                string encryptedBase64 = File.ReadAllText(file);
                string json = WindowsDataProtection.UnprotectFromBase64(encryptedBase64);
                PasswordEntry? entry = JsonSerializer.Deserialize<PasswordEntry>(json, JsonOptions);

                if (entry != null && !string.IsNullOrWhiteSpace(entry.Password))
                {
                    entry.FilePath = file;
                    entries.Add(entry);
                }
            }
            catch
            {
                // Ignore files that cannot be decrypted by this Windows user.
            }
        }

        // Legacy support: old 1.2.0 Markdown files can still be listed.
        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            try
            {
                string text = File.ReadAllText(file);

                PasswordEntry entry = new()
                {
                    SaveName = MatchValue(text, @"\*\*Save Name:\*\*\s*(.+)") + " (Legacy Plain Text)",
                    Username = MatchValue(text, @"\*\*Username:\*\*\s*(.+)"),
                    Password = MatchValue(text, @"\*\*Password:\*\*\s*`([^`]*)`"),
                    FilePath = file
                };

                string created = MatchValue(text, @"\*\*Created:\*\*\s*(.+)");
                if (DateTime.TryParse(created, out DateTime parsed))
                {
                    entry.CreatedLocal = parsed;
                }
                else
                {
                    entry.CreatedLocal = File.GetCreationTime(file);
                }

                if (!string.IsNullOrWhiteSpace(entry.Password))
                {
                    entries.Add(entry);
                }
            }
            catch
            {
                // Ignore broken legacy files.
            }
        }

        return entries.OrderByDescending(entry => entry.CreatedLocal).ToList();
    }

    public static PasswordEntry SaveEntry(string folder, PasswordEntry entry)
    {
        Directory.CreateDirectory(folder);

        if (entry.CreatedLocal == default)
        {
            entry.CreatedLocal = DateTime.Now;
        }

        string safeName = MakeSafeFileName(entry.SaveName);
        if (string.IsNullOrWhiteSpace(safeName))
        {
            safeName = "password";
        }

        bool isLegacyMarkdown = entry.FilePath.EndsWith(".md", StringComparison.OrdinalIgnoreCase);
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        string path = string.IsNullOrWhiteSpace(entry.FilePath) || isLegacyMarkdown
            ? Path.Combine(folder, $"{safeName}_{timestamp}.spgs")
            : entry.FilePath;

        PasswordEntry cleanEntry = new()
        {
            SaveName = entry.SaveName.Replace(" (Legacy Plain Text)", "").Trim(),
            Username = entry.Username,
            Password = entry.Password,
            CreatedLocal = entry.CreatedLocal,
            FilePath = ""
        };

        string json = JsonSerializer.Serialize(cleanEntry, JsonOptions);
        string encryptedBase64 = WindowsDataProtection.ProtectToBase64(json);

        File.WriteAllText(path, encryptedBase64);
        entry.FilePath = path;
        entry.SaveName = cleanEntry.SaveName;
        return entry;
    }

    public static void DeleteEntry(PasswordEntry entry)
    {
        if (!string.IsNullOrWhiteSpace(entry.FilePath) && File.Exists(entry.FilePath))
        {
            File.Delete(entry.FilePath);
        }
    }

    public static void DeleteAll(string folder)
    {
        Directory.CreateDirectory(folder);

        foreach (string file in Directory.GetFiles(folder, "*.spgs"))
        {
            File.Delete(file);
        }

        foreach (string file in Directory.GetFiles(folder, "*.md"))
        {
            File.Delete(file);
        }
    }

    public static void OpenFolder(string folder)
    {
        Directory.CreateDirectory(folder);

        ProcessStartInfo psi = new()
        {
            FileName = folder,
            UseShellExecute = true
        };

        Process.Start(psi);
    }

    private static string MatchValue(string text, string pattern)
    {
        Match match = Regex.Match(text, pattern);
        return match.Success ? match.Groups[1].Value.Trim() : "";
    }

    private static string MakeSafeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars())
        {
            name = name.Replace(c, '_');
        }

        return name.Trim();
    }
}
