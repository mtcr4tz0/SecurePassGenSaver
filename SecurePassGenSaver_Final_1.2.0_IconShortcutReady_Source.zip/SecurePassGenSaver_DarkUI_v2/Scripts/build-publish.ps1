$ErrorActionPreference = "Stop"

Write-Host "Building SecurePassGenSaver 1.2.0 as a self-contained single-file EXE..." -ForegroundColor Cyan

$projectRoot = Split-Path -Parent $PSScriptRoot
$publishDir = Join-Path $projectRoot "Publish"

if (Test-Path $publishDir) {
    Remove-Item $publishDir -Recurse -Force
}

dotnet publish "$projectRoot\SecurePassGenSaver.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained true `
    /p:PublishSingleFile=true `
    /p:IncludeNativeLibrariesForSelfExtract=true `
    /p:EnableCompressionInSingleFile=true `
    /p:PublishTrimmed=false `
    /p:DebugType=None `
    /p:DebugSymbols=false `
    /p:PublishDir="$publishDir\"

Write-Host ""
Write-Host "Build complete." -ForegroundColor Green
Write-Host "Output:"
Write-Host "$publishDir\SecurePassGenSaver.exe"
Write-Host ""
Write-Host "The EXE should use the SecurePassGenSaver key icon."
Write-Host ""
Write-Host "To create the installer:"
Write-Host "Open Installer\SecurePassGenSaver.iss in Inno Setup and press Compile."
